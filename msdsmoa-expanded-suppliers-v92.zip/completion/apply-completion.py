import argparse,re,json,hashlib,shutil
from pathlib import Path
from html import escape,unescape
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();lookup='https://www.kpic.co.kr/hp/kr/cs/cs_data_jp.asp?grade=&item=1&page=7';changed=0
def write(f,s):
 global changed
 if f.read_text()==s:return
 b=a.backup/f.relative_to(a.site);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():shutil.copy2(f,b)
 f.write_text(s);changed+=1
for f in a.site.rglob('*.html'):
 s=f.read_text()
 if '대한유화' not in s:continue
 def fix(m):
  t=m[0];v=re.search(r'href=([\"\x27])(.*?)\1',t,re.S)
  if not v or not unescape(v[2]).lower().startswith('javascript:') or not ('action' in t or 'MSDS' in t or '다운로드' in t):return t
  start=t[:t.index('>')+1];return start[:v.start(2)]+escape(lookup,quote=True)+start[v.end(2):]+'공식 자료실에서 제품명으로 찾기</a>'
 write(f,re.sub(r'<a\b[^>]*>.*?</a>',fix,s,flags=re.S|re.I))
f=a.site/'index.html';h=f.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];s=(a.site/old[1:]).read_text()
if '// completion-v89' not in s:
 oldline='const linkIssue = linkIssuesV88[product.url];';assert oldline in s;s=s.replace(oldline,"const invalidPrimary = !!product.url && !/^https?:\\/\\//i.test(product.url);\n  const linkIssue = linkIssuesV88[product.url] || (invalidPrimary ? (product.company === '대한유화' ? "+json.dumps(lookup)+" : '/manufacturers.html') : '');")
 s=s.replace("if (linkIssue) details.append(element('p', '2026-11-25 확인: 원문 파일이 없어 공급사에 MSDS 요청이 필요합니다.', 'source-caution'));","if (linkIssue) details.append(element('p', invalidPrimary ? '직접 다운로드 경로가 등록되지 않았습니다. 공식 자료실에서 제품명과 언어를 확인하세요.' : '2026-11-25 확인: 원문 파일이 없어 공급사에 MSDS 요청이 필요합니다.', 'source-caution'));")
 s=s.replace("linkIssue ? '공급사에서 MSDS 요청' :","linkIssue ? (invalidPrimary ? '공식 자료실에서 찾기' : '공급사에서 MSDS 요청') :")
 s=s.replace('for (const download of product.additionalDownloads) {',"for (const download of product.additionalDownloads.filter(item => /^https?:\\/\\//i.test(item.url))) {")
 s+='\n// completion-v89\n';new='/assets/home-search-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js';(a.site/new[1:]).write_text(s);write(f,h.replace(old,new))
print('COMPLETION V89 COMPLETE',changed)
