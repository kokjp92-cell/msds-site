from pathlib import Path
from urllib.parse import urlparse, parse_qsl
from html import escape, unescape
from collections import defaultdict
import hashlib
import json
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
data = json.loads(Path(__file__).with_name("tspc-products.json").read_text())
home = root / "index.html"
directory = root / "manufacturers.html"
source = home.read_text()
match = re.search(r'<script src="(/assets/home-search-[a-f0-9]+\.js)" defer></script>', source)
if not match:
    raise SystemExit("Search bundle not found. No changes.")
bundle = (root / match.group(1).lstrip("/")).read_text()
if "tspc-documents-v1" in bundle:
    raise SystemExit("TSPC patch already applied.")
anchor = "const results = document.querySelector('#results');"
if bundle.count(anchor) != 1:
    raise SystemExit("Unexpected search structure. No changes.")

def key(url):
    parsed = urlparse(unescape(url))
    return (parsed.path, tuple(sorted(parse_qsl(parsed.query))))

existing = {key(url) for url in re.findall(r'https?://www\.tspc\.co\.kr/[^"\s<>]+', bundle)}
fresh = [row for row in data if key(row["url"]) not in existing]
labels = {"ko": "국문"}
official = "https://www.tspc.co.kr/ko/pages/an.php"
records = [
    {"company": "동서석유화학", "name": row["name"],
     "keywords": "동서석유화학 TSPC " + row["name"],
     "url": row["url"], "verifiedList": row["source"],
     "detail": "국문" + " SDS · 제조사 공식 다운로드",
     "label": "국문" + " SDS 다운로드 ↗",
     "instructions": "문서의 적용 국가·언어와 제품 등급 및 개정일을 확인하세요.",
     "documentLanguage": "ko"}
    for row in fresh
]
bundle = bundle.replace(anchor, "// tspc-documents-v1\nproducts.push(..." + json.dumps(records, ensure_ascii=False) + ");\n" + anchor, 1)
totals = set(re.findall(r'등록 자료 ([\d,]+)건', bundle))
if len(totals) == 1:
    old = totals.pop()
    new = f"{int(old.replace(',', '')) + len(fresh):,}"
    bundle = bundle.replace(old + "건", new + "건")
    source = source.replace(old + "건", new + "건")
bundle_name = "home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
source = source.replace(match.group(1), "/assets/" + bundle_name, 1)
directory_html = directory.read_text()
base = "manufacturer-tspc"
if base not in directory_html:
    card = f'<article class="row"><div><h2>동서석유화학 MSDS</h2><p class="meta">AN·청화소다·아세토니트릴 국문 MSDS</p></div><a class="action" href="/{base}.html">MSDS 자료실 보기 →</a></article>'
    if directory_html.count("</main>") != 1:
        raise SystemExit("Unexpected manufacturer directory. No changes.")
    directory_html = directory_html.replace("</main>", card + "</main>", 1)
style = re.search(r'<link[^>]*href="(/site-clean\.css[^"]*)"', directory_html)
stylesheet = style.group(1) if style else "/site-clean.css"
groups = defaultdict(list)
for row in data:
    groups[row["name"]].append(row)
names = sorted(groups)
chunks = [names[i:i + 50] for i in range(0, len(names), 50)]
filenames = [base + ("" if i == 0 else "-" + str(i + 1)) + ".html" for i in range(len(chunks))]
outputs = {}
for i, chunk in enumerate(chunks):
    navigation = ' · '.join(f'<a href="/{name}"'+(' aria-current="page"' if n == i else '')+f'>{n + 1}</a>' for n, name in enumerate(filenames))
    cards = ""
    for name in chunk:
        links = " ".join(f'<a class="action" href="{escape(row["url"], quote=True)}" target="_blank" rel="noopener noreferrer">{"국문"} SDS ↗</a>' for row in groups[name])
        cards += f'<article class="row"><div><h2>{escape(name)}</h2><p class="meta">제조사 공식 MSDS</p></div><div class="result-actions">{links}</div></article>'
    url = "https://msdsmoa.com/" + filenames[i]
    outputs[root / filenames[i]] = f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>동서석유화학 MSDS {i + 1}페이지 | MSDS 모아</title><meta name="description" content="동서석유화학 {escape(chunk[0], quote=True)}부터 {escape(chunk[-1], quote=True)}까지의 제품의 국문 MSDS를 확인하세요.">
<link rel="canonical" href="{url}"><link rel="stylesheet" href="{escape(stylesheet, quote=True)}"></head>
<body><header><nav class="wrap"><a class="brand" href="/">MSDS 모아</a><a class="action" href="/manufacturers.html">제조사별 MSDS 자료실 보기</a></nav><div class="wrap hero"><h1>동서석유화학 MSDS</h1></div></header>
<main class="wrap"><nav aria-label="현재 위치"><a href="/manufacturers.html">제조사별 자료실</a> › 동서석유화학</nav><p>제품명과 원문 개정일을 확인하세요.</p>
<p><a href="{official}" target="_blank" rel="noopener noreferrer">제조사 공식 자료실 ↗</a></p><nav aria-label="자료 페이지">{navigation}</nav>{cards}<nav aria-label="자료 페이지 하단">{navigation}</nav></main>
<footer><div class="wrap"><a href="/">MSDS 모아</a> · <a href="/manufacturers.html">제조사별 자료실</a></div></footer></body></html>'''
tree = ET.parse(root / "sitemap.xml")
namespace = "http://www.sitemaps.org/schemas/sitemap/0.9"
ET.register_namespace("", namespace)
known = {node.text for node in tree.findall(f".//{{{namespace}}}loc")}
for name in filenames:
    url = "https://msdsmoa.com/" + name
    if url not in known:
        node = ET.SubElement(tree.getroot(), f"{{{namespace}}}url")
        ET.SubElement(node, f"{{{namespace}}}loc").text = url
if len(tree.getroot()) > 50000:
    raise SystemExit("Sitemap limit exceeded. No changes.")
outputs[root / "assets" / bundle_name] = bundle
outputs[root / "sitemap.xml"] = ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True)
outputs[directory] = directory_html
outputs[home] = source
for path, content in outputs.items():
    temporary = path.with_name(path.name + ".tspc-tmp")
    try:
        temporary.write_text(content, encoding="utf-8")
        if path.exists():
            shutil.copystat(path, temporary)
        else:
            temporary.chmod(0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
print(f"TSPC COMPLETE: {len(fresh)} new documents; {len(data) - len(fresh)} existing documents skipped; {len(filenames)} listing pages")
