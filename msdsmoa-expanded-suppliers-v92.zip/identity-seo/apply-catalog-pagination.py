import argparse,re,shutil
from pathlib import Path
from html import escape,unescape
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();changed=0;checked=0
for f in sorted(a.site.glob('manufacturer-*.html')):
 s=f.read_text();main=re.search(r'<main\b[^>]*>(.*?)</main>',s,re.S|re.I)
 if not main:continue
 text=unescape(re.sub(r'<[^>]*>',' ',main[1]));page=re.search(r'(\d+)\s*/\s*(\d+)\s*페이지',text)
 if not page or int(page[2])<=1:continue
 current,total=map(int,page.groups())
 if current<1 or current>total:raise ValueError('Invalid visible page counter: '+str(f))
 title=re.search(r'<title>(.*?)</title>',s,re.S|re.I);heading=re.search(r'<h1[^>]*>(.*?)</h1>',s,re.S|re.I)
 if not title or not heading:raise ValueError('Catalog metadata missing: '+str(f))
 name=unescape(re.sub(r'<[^>]*>','',heading[1])).strip();base=re.sub(r'\s*[—–-]\s*\d+페이지\s*$','',unescape(title[1]).split(' | MSDS 모아')[0]);newtitle=base+' — '+str(current)+'페이지 | MSDS 모아';desc=name+' 자료 목록 '+str(current)+' / '+str(total)+'페이지입니다. 이 페이지의 제품명과 문서 정보를 확인하고 공급사 원문으로 이동하세요.'
 out=re.sub(r'<title>.*?</title>','<title>'+escape(newtitle)+'</title>',s,count=1,flags=re.S|re.I);out=re.sub(r'<meta\b(?=[^>]*name=[\"\x27]description[\"\x27])[^>]*>','<meta name="description" content="'+escape(desc,quote=True)+'">',out,count=1,flags=re.I);checked+=1
 if out!=s:
  b=a.backup/f.name;b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():shutil.copy2(f,b)
  f.write_text(out);changed+=1
print('CATALOG PAGINATION SEO V91 COMPLETE',checked,'pages;',changed,'changed')
