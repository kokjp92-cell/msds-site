"""Apply pending and new supplier updates in order."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
package = Path(__file__).resolve().parent
for supplier in ("samyuk-ka", "tau-htc-kc", "new-suppliers", "catalog-expansion", "verified-pdfs", "additional", "polymer-tdi", "new-companies", "auto-fluids", "fresh-sources", "epoxy-and-supplies", "refrigerants-brazing", "coatings-adhesives", "metals-batteries", "taejin", "jeil-welding", "hanil-industrial", "auto-welding", "coffee-cleaners", "industrial-materials", "bdtech", "chemicals-biochem", "farm-and-adhesives", "sm-industry", "chilman"):
    script = package / supplier / f"apply-{supplier}.py"
    subprocess.run(
        [sys.executable, str(script), str(args.site), "--backup", str(args.backup / supplier)],
        check=True,
    )
