#!/usr/bin/env bash
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
site_dir=${1:-/var/www/msdsmoa}
backup_dir=${2:-$(mktemp -d /home/ubuntu/msdsmoa-v91-backup.XXXXXX)}
echo "Backup: $backup_dir"
python3 "$package_dir/apply-expanded-suppliers.py" "$site_dir" --backup "$backup_dir"
python3 "$package_dir/sitewide-quality/verify-sitewide-quality.py" "$site_dir"
python3 "$package_dir/seo/verify-seo.py" "$site_dir"
python3 "$package_dir/completion/verify-source-inventory.py" "$site_dir"
echo 'V91 LOCAL DEPLOY VERIFY OK'
echo "Backup: $backup_dir"

echo "Duplicate report: https://msdsmoa.com/seo-duplicate-report-v91.json"
