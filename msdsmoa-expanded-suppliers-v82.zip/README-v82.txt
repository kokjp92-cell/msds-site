MSDS 모아 v82 / 2026-11-25
기존 v81 및 모든 이전 추가분 포함 누적 패키지. MOLYKOTE YM-102, SK-623, PG-75 Plastislip, G-4500 FMS, 111 Compound 국문 SDS 5건 추가.
전체 PDF 다운로드·제품명·회사·개정일·해시 확인. 공식 링크를 제공하며 원본 PDF 재배포하지 않음. 전체 성분/유해성 기술 심사 아님. 111과 PG-75는 각각 2022/2023 개정 공개 보관본으로 최신본은 공급자 확인 필요. G-4500 FMS는 원문 개정일 2026-02-26 확인.
배포 후 홈45,133건, 공급사221개, MOLYKOTE13건, 사이트맵45,441 URL 예상. 검색·상세·자료실·사이트맵·법령/보호구·제휴 고지 연결, 기존 주소/데이터 보존, 재실행 검사 통과. 로컬982개 부분 상세파일 검사이며 실서버 전체 검사는 별도 필요.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v82-backup
배포 후 검사: python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
서버 배포 수행하지 않음. chemical-additions-v82.csv / verified-sources-v82.json 참고.
