MSDS 모아 v85 / 2026-11-25
기존 v84와 모든 이전 추가분 포함 누적 패키지. 한국이콜랩 신규5건: EASY CLEAN DISH MACHINE DETERGENT, AC-356, COSA CIP72, CLEAN DIP PLUS, ENCOMPASS. 기존 이콜랩10건 보존, 합계15건.
공식 서버 전체PDF 다운로드·제품명·회사·실제 원문 개정일·해시 확인. 원본 PDF 재배포하지 않고 링크와 식별 메모 제공. 전체 성분/유해성 기술 심사 아님. 원액/희석액을 나누어 수량 부풀리지 않음.
각 개정일2026-02-02, 2026-04-28, 2026-02-11, 2026-02-05, 2021-04-11. ENCOMPASS는 오래된 보관본으로 현행성 보증 없음. 납품업체 최신본과 대조 필요.
GST5건은HTTP503, WEICON4건은HTTP500으로 전체PDF 확인 실패하여 미등록. 검색 노출만으로 정상 링크라고 판정하지 않음.
배포 후 홈45,154건 / 자료실카드223개 / 사이트맵45,464 URL / 식별설명410건 예상. 로컬1003개 부분 상세파일의 검색·상세·자료실·사이트맵·법령/보호구·제휴 고지 연결, 기존 주소/데이터 보존, 재실행 검사 통과. 실서버 전체 검사는 별도.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v85-backup
배포 후 검사: python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
서버 배포 수행하지 않음. chemical-additions-v85.csv / verified-sources-v85.json 참고.
