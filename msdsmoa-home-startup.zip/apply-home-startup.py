"""Render the manufacturer list before loading the full search catalog."""
import argparse
import hashlib
import json
from html import escape, unescape
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
if 'id="msds-search-bundle"' in html:
    print("Home startup patch already applied.")
    raise SystemExit(0)

search = re.search(r'<script src="(/assets/home-search-[a-f0-9]+\.js)" defer></script>', html)
results = re.search(r'(<section\b[^>]*\bid="results"[^>]*>)(.*?)</section>', html, re.S)
if not search or not results or 'id="msds-detail-index"' not in html:
    raise SystemExit("Expected the home performance patch and results section. No changes made.")

original = args.site / search[1][1:]
bundle = original.read_text(encoding="utf-8")
bundle = replace_once(bundle, "if (typeof location !== 'undefined') query.value", "if (typeof location !== 'undefined' && !document.getElementById('msds-search-bundle')) query.value")
asset = "/assets/home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
directory = (args.site / "manufacturers.html").read_text(encoding="utf-8")
cards = re.findall(r'<article class="row"><div><h2>([^<]+)</h2>(.*?)</article>', directory, re.S)
makers = {}
for title, card in cards:
    count = re.search(r'등록 자료 ([\d,]+)건', card)
    href = re.search(r'href="(/?manufacturer-[\w-]+\.html)"', card)
    if count and href:
        makers[unescape(title).removesuffix(" MSDS")] = (count[1], href[1])
if len(makers) < 10:
    raise SystemExit("Could not read manufacturer counts. No changes made.")
order = re.search(r'const makerDisplayOrder = (\[[^\n]+\]);', bundle)
if not order:
    raise SystemExit("Could not read manufacturer ordering. No changes made.")
# Retain the order used by the interactive search.
rank = {name: index for index, name in enumerate(json.loads(order[1]))}
rows = []
for name, (count, href) in sorted(makers.items(), key=lambda item: (rank.get(item[0], len(rank)), item[0])):
    label = escape(name)
    rows.append(f'<details class="maker" data-company="{label}"><summary>{label}'
                f'<span class="maker-count">{count}건</span></summary>'
                f'<div class="maker-products"><a href="{href}">자료 목록 보기 →</a></div></details>')

html = replace_once(html, results[0], results[1] + "".join(rows) + results[2] + "</section>")
html = replace_once(html, "전체 자료를 검색할 수 있도록 목록을 준비하고 있습니다.",
                    "제품명으로 검색하거나 제조사를 펼쳐 자료를 확인하세요.")
bootstrap = Path(__file__).with_name("startup.js").read_text(encoding="utf-8")
html = replace_once(html, search[0], f'<meta id="msds-search-bundle" content="{asset}"><script>{bootstrap}</script>')

args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
publish(args.site / asset[1:], bundle, 0o644)
publish(home, html, home.stat().st_mode)
print(f"HOME STARTUP COMPLETE: {len(makers)} manufacturers\nBackup: {args.backup / home.name}")
