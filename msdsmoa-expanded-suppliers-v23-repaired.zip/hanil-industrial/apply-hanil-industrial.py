"""Add verified supplier catalog entries to MSDS Moa."""
import argparse
from collections import defaultdict
import hashlib
from html import escape
import xml.etree.ElementTree as ET
import json
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def asset(name, content, extension):
    digest = hashlib.sha256(content.encode()).hexdigest()[:12]
    return f"/assets/{name}-{digest}.{extension}"


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
root = args.site
package = Path(__file__).parent
home = root / "index.html"
directory = root / "manufacturers.html"
sitemap = root / "sitemap.xml"
html = home.read_text(encoding="utf-8")
search = re.search(r'id="msds-search-bundle" content="(/assets/home-search-[a-f0-9]+\.js)"', html)
detail = re.search(r'id="msds-detail-index" content="(/assets/detail-index-[a-f0-9]+\.js)"', html)
if not search or not detail:
    raise SystemExit("Expected the optimized home. No changes made.")
bundle = (root / search[1][1:]).read_text(encoding="utf-8")
if "// hanil-industrial-documents-v1" in bundle:
    print("Suppliers already added.")
    raise SystemExit(0)
prefix = "window.msdsDetailIndex="
raw = (root / detail[1][1:]).read_text(encoding="utf-8").strip()
if not raw.startswith(prefix):
    raise SystemExit("Unexpected detail index. No changes made.")
index = json.loads(raw[len(prefix):].removesuffix(";"))
rows = json.loads((package / "hanil-industrial-products.json").read_text(encoding="utf-8"))
companies = {'한일산업': 'hanil-industrial'}

def compact(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def render(template, fields):
    return re.sub(r"\{\{([A-Z]+)\}\}", lambda m: fields[m[1]], template)


namespace = "http://www.sitemaps.org/schemas/sitemap/0.9"
ET.register_namespace("", namespace)
tree = ET.parse(sitemap)
known = {item.text for item in tree.findall(f".//{{{namespace}}}loc")}

def include_url(url):
    if url not in known:
        node = ET.SubElement(tree.getroot(), f"{{{namespace}}}url")
        ET.SubElement(node, f"{{{namespace}}}loc").text = url
        known.add(url)


detail_template = (package / "detail-template.html").read_text(encoding="utf-8")
catalog_template = (package / "catalog-template.html").read_text(encoding="utf-8")
outputs = {}
directory_cards = []
records = []
site = "https://msdsmoa.com"
for company, slug in companies.items():
    entries = [row for row in rows if row["company"] == company]
    catalog = f"/manufacturer-{slug}.html"
    source = entries[0]["source"]
    cards = []
    for row in entries:
        name, url = row["name"], row["url"]
        key = compact([company, name, url])
        if key in index or compact([company, name]) in index:
            raise SystemExit(f"Existing detail link for {company} / {name}. No changes made.")
        detail_url = "/products/" + hashlib.sha256(key.encode()).hexdigest()[:24] + ".html"
        canonical = site + detail_url
        index[key] = detail_url
        include_url(canonical)
        fields = dict(TITLE=f"{company} {name} MSDS", DESCRIPTION=f"{company} {name} 공급사 공식 MSDS.",
                      CANONICAL=canonical, NAME=name, COMPANY=company, FORMAT=row["format"],
                      PDF=url, BUTTON=row["button"], SOURCE=source, CATALOG=catalog)
        outputs[detail_url] = render(detail_template, {k: escape(v) for k, v in fields.items()})
        records.append(dict(company=company, name=name, url=url, verifiedList=source,
                            keywords=f"{company} {name}",
                            detail=row["format"], label=row["button"],
                            instructions="공급사 원문에서 제품명과 개정일을 확인하세요."))
        cards.append(
            f'<article class="row catalog-item" data-search="{escape(company + " " + name)}">'
            f'<div><div class="status">{company} · {escape(row["format"])}</div><h3><a href="{detail_url}">{escape(name)}</a></h3></div>'
            f'<div class="result-actions"><a class="action" href="{escape(url)}" target="_blank" '
            f'rel="noopener noreferrer">{escape(row["button"])}</a></div></article>'
        )
    outputs[catalog] = render(catalog_template, dict(COMPANY=company, COUNT=str(len(entries)),
                                                    SLUG=catalog[1:-5], SOURCE=source, CARDS="".join(cards)))
    include_url(site + catalog)
    directory_cards.append(
        f'<article class="row"><div><h2>{company} MSDS</h2><p class="meta">국문 MSDS 원문 또는 공급사 첨부 자료로 연결합니다.</p>'
        f'<p class="catalog-count">등록 자료 {len(entries)}건</p></div><a class="action" href="{catalog}">자료 목록 보기 →</a></article>'
    )
if len(tree.getroot()) > 50000:
    raise SystemExit("Sitemap limit exceeded. No changes made.")

index_js = prefix + compact(index) + ";\n"
detail_path = asset("detail-index", index_js, "js")
outputs[detail_path] = index_js
groups = defaultdict(dict)
for key, destination in index.items():
    groups[json.loads(key)[0]][key] = destination
manifest = {}
for company, entries in sorted(groups.items()):
    content = compact(entries)
    path = asset("detail-company", content, "json")
    manifest[company] = path
    if not (root / path[1:]).is_file():
        outputs[path] = content

for name, value in [("manufacturerDetailSource", detail_path), ("manufacturerDetailFiles", manifest)]:
    old = re.search(rf"(?m)^const {name} = .+;$", bundle)
    if not old:
        raise SystemExit("Expected manufacturer-specific detail links. No changes made.")
    bundle = replace_once(bundle, old[0], f"const {name} = {compact(value)};")
anchor = "const results = document.querySelector('#results');"
bundle = replace_once(bundle, anchor, "// hanil-industrial-documents-v1\nproducts.push(..." + compact(records) + ");\n" + anchor)
total = re.search(r'등록 자료 ([\d,]+)건', html)
if not total:
    raise SystemExit("Could not find the home document count.")
new_total = f"{int(total[1].replace(',', '')) + len(records):,}"
html = html.replace(total[1] + "건", new_total + "건")
bundle = bundle.replace(total[1] + "건", new_total + "건")
search_path = asset("home-search", bundle, "js")
outputs[search_path] = bundle
html = replace_once(html, search[1], search_path)
html = replace_once(html, detail[1], detail_path)
directory_html = directory.read_text(encoding="utf-8")
reference = re.search(r'<article class="row">(?:(?!</article>).)*href="/?manufacturer-zeller\.html"(?:(?!</article>).)*</article>', directory_html, re.S)
if not reference:
    raise SystemExit("Could not locate the manufacturer directory cards.")
directory_html = replace_once(directory_html, reference[0], reference[0] + "".join(directory_cards))

args.backup.mkdir(parents=True, exist_ok=False)
for page in (home, directory, sitemap):
    shutil.copy2(page, args.backup / page.name)
for url, content in outputs.items():
    publish(root / url[1:], content, 0o644)
publish(sitemap, ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True), sitemap.stat().st_mode)
publish(directory, directory_html, directory.stat().st_mode)
publish(home, html, home.stat().st_mode)
print(f"NEW SUPPLIERS COMPLETE: {len(records)} documents, {len(companies)} suppliers\nBackup: {args.backup}")
