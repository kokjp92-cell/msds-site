MSDS 모아 누적 v87 / 2026-11-25
기존 v86 SEO 및 v85까지 모든 MSDS 추가분 포함. 신규 문서 증가는 없음. 홈45,154건 / 카드223개 / 사이트맵45,464URL 유지.
SEO: 정적 JSON-LD WebSite/WebPage/CollectionPage/BreadcrumbList, HTTPS 대표주소와 설명 보완, 전체 SEO 검사 유지. 화면에 없는 리뷰·가격·성분 등을 만들지 않음.
내부검색: Unicode NFKC·대소문자·공백 및 여러 하이픈 표기 정규화. G-4500/G4500, AW 32/AW32, calcium chloride/calciumchloride, 염화 칼슘/염화칼슘 표기 차이를 검색에서 허용. 원본 제품명/문서주소는 수정하지 않음. 소수점/퍼센트 표시는 유지하여3.0%를30%로 합치지 않음. 오타 교정·물질명 번역·등급 호환 판단 기능은 아님. 입력160ms지연 및 한글조합 처리, 검색 시에만 큰자료파일 로딩하는 기존 동작 유지. 텍스트 캐시 재사용.
검사: 정규화 양성/음성 사례, 실제 카탈로그/전체 상세주소 매핑 검색, JS문법, SEO1104HTML, 기존 본문·링크·데이터 보존, 전체 설치 재실행 불변. 실서버 전체파일 및 실제 브라우저 성능/색인은 배포 후 확인 필요.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v87-backup
마지막 자동SEO검사 errors0 확인. 별도검사: python3 seo/verify-seo.py /var/www/msdsmoa
서버 배포 및 Search Console 제출은 수행하지 않음. 검색순위·색인·애드센스 승인 보장 없음.
