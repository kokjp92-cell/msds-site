from pathlib import Path
import os
import re
import shutil
import sys

root = Path(sys.argv[1]).resolve()
style = Path(__file__).with_name("site-clean.css")
if not (root / "index.html").is_file():
    raise SystemExit("Site index.html not found. Stopped.")
shutil.copy2(style, root / "site-clean.css")
tag = '<link rel="stylesheet" href="/site-clean.css?v=20261111c">'
count = 0
for page in root.rglob("*.html"):
    if page.is_symlink():
        continue
    html = page.read_text(encoding="utf-8")
    updated = re.sub(r'<link\b[^>]*href=["\']/site-clean\.css[^"\']*["\'][^>]*>', '', html)
    if "</head>" in updated:
        updated = updated.replace("</head>", tag + "</head>", 1)
    elif "<body" in updated:
        updated = updated.replace("<body", tag + "<body", 1)
    elif "<header" in updated:
        updated = updated.replace("<header", tag + "<header", 1)
    else:
        raise SystemExit(f"No insertion point: {page}")
    if page.name == "ppe-guide.html":
        updated = re.sub(r'<section\b[^>]*>\s*<h2>유형별 구매 참고</h2>.*?</section>', '', updated, flags=re.S)
    temporary = page.with_name(page.name + ".ui-tmp")
    try:
        temporary.write_text(updated, encoding="utf-8")
        shutil.copystat(page, temporary)
        os.replace(temporary, page)
    finally:
        temporary.unlink(missing_ok=True)
    count += 1
print(f"UI COMPLETE: {count} pages")
