import argparse,json,re
from pathlib import Path
from html import unescape
from html.parser import HTMLParser
from locale_fields import Card
class Meta(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.title='';self.in_title=False;self.description=''
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='title':self.in_title=True
  if t=='meta' and a.get('name')=='description':self.description=a.get('content','')
 def handle_endtag(self,t):
  if t=='title':self.in_title=False
 def handle_data(self,s):
  if self.in_title:self.title+=s
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);a=ap.parse_args();checked=0;errors=[]
for f in (a.site/'products').glob('*.html'):
 s=f.read_text();c=Card();c.feed(s);fmt=next((v for v in c.props.values() if '언어' in v and '국가' in v),'');lang=re.search(r'언어\s+([^·]+)',fmt);country=re.search(r'국가\s+([^·]+)',fmt)
 if not lang or not country:continue
 checked+=1;m=Meta();m.feed(s)
 if any(x not in m.title or x not in m.description for x in [lang[1].strip(),country[1].strip()]):errors.append(str(f.relative_to(a.site)))
print(json.dumps(dict(explicit_locale_pages_checked=checked,error_count=len(errors),errors=errors[:30]),ensure_ascii=False));raise SystemExit(bool(errors))
