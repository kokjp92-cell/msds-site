from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
data = json.loads(Path(__file__).with_name("zeller-products.json").read_text())
home = root / "index.html"
directory = root / "manufacturers.html"
source = home.read_text()
match = re.search(r'<script src="(/assets/home-search-[a-f0-9]+\.js)" defer></script>', source)
if not match:
    raise SystemExit("Search bundle not found. No changes.")
bundle = (root / match.group(1).lstrip("/")).read_text()
if "zeller-documents-v1" in bundle:
    print("뉴젠텍루브켐 patch already applied.")
    raise SystemExit(0)
anchor = "const results = document.querySelector('#results');"
if bundle.count(anchor) != 1:
    raise SystemExit("Unexpected search structure. No changes.")

existing = {record['name'] for line in bundle.splitlines()
            if line.startswith('products.push(...[') and line.endswith(');') and '뉴젠텍루브켐' in line
            for record in json.loads(line[len('products.push(...'):-2])
            if record.get('company') == '뉴젠텍루브켐'}
fresh = [row for row in data if row['name'] not in existing]
records = [
    {"company": "뉴젠텍루브켐", "name": row["name"],
     "keywords": "뉴젠텍루브켐 ZELLER DIVINOL " + row["name"] + " " + row["code"],
     "url": row["url"], "verifiedList": row["source"],
     "detail": "공급사 공식 MSDS 게시글",
     "label": "공식 MSDS 게시글 보기 ↗",
     "instructions": "공급사 게시글에서 해당 제품의 첨부파일을 선택하세요. 제품 코드와 개정일을 확인하세요."}
    for row in fresh
]
bundle = bundle.replace(anchor, "// zeller-documents-v1\nproducts.push(..." + json.dumps(records, ensure_ascii=False) + ");\n" + anchor, 1)
totals = set(re.findall(r'등록 자료 ([\d,]+)건', bundle))
if len(totals) == 1:
    old = totals.pop()
    new = f"{int(old.replace(',', '')) + len(fresh):,}"
    bundle = bundle.replace(old + "건", new + "건")
    source = source.replace(old + "건", new + "건")
bundle_name = "home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
source = source.replace(match.group(1), "/assets/" + bundle_name, 1)
directory_html = directory.read_text()
base = "manufacturer-zeller"
if base not in directory_html:
    reference = re.search(r'<article class="row">(?:(?!</article>).)*href="/?manufacturer-foosung\.html"(?:(?!</article>).)*</article>', directory_html, re.S)
    if not reference:
        raise SystemExit("Manufacturer list section not found. No changes.")
    card = '<article class="row"><div><h2>뉴젠텍루브켐 MSDS</h2><p class="meta">뉴젠텍루브켐 MSDS 공식 게시글로 연결합니다.</p><p class="catalog-count">등록 자료 300건</p></div><a class="action" href="manufacturer-zeller.html">자료 목록 보기 →</a></article>'
    directory_html = directory_html[:reference.end()] + card + directory_html[reference.end():]
filenames = [base + ".html"]
page = Path(__file__).with_name(filenames[0]).read_text()
if not (root / "site-width-960.css").exists():
    page = page.replace('<link rel="stylesheet" href="/site-width-960.css">', '')

outputs = {root / filenames[0]: page}
tree = ET.parse(root / "sitemap.xml")
namespace = "http://www.sitemaps.org/schemas/sitemap/0.9"
ET.register_namespace("", namespace)
known = {node.text for node in tree.findall(f".//{{{namespace}}}loc")}
for name in filenames:
    url = "https://msdsmoa.com/" + name
    if url not in known:
        node = ET.SubElement(tree.getroot(), f"{{{namespace}}}url")
        ET.SubElement(node, f"{{{namespace}}}loc").text = url
if len(tree.getroot()) > 50000:
    raise SystemExit("Sitemap limit exceeded. No changes.")
outputs[root / "assets" / bundle_name] = bundle
outputs[root / "sitemap.xml"] = ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True)
outputs[directory] = directory_html
from build_details import prepare_details
source, detail_outputs = prepare_details(root, source, outputs[root / filenames[0]], tree, data)
outputs.update(detail_outputs)
outputs[root / "sitemap.xml"] = ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True)
outputs[home] = source
for path, content in outputs.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".zeller-tmp")
    try:
        temporary.write_text(content, encoding="utf-8")
        if path.exists():
            shutil.copystat(path, temporary)
        else:
            temporary.chmod(0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
print(f"뉴젠텍루브켐 COMPLETE: {len(fresh)} new documents; {len(data) - len(fresh)} existing documents skipped; {len(filenames)} listing pages")
