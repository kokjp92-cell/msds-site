"""Add factual, server-rendered page and breadcrumb metadata; no ranking claims."""
import argparse,json,re,shutil
from pathlib import Path
from html import escape
from html.parser import HTMLParser
from urllib.parse import urljoin
BASE='https://msdsmoa.com'
class Tags(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.title='';self.h1='';self.desc='';self.robots='';self.cap=None;self.nav=0;self.anchor=None;self.crumbs=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag in ('title','h1'):self.cap=tag
  if tag=='meta' and a.get('name','').lower()=='description':self.desc=a.get('content','')
  if tag=='meta' and a.get('name','').lower()=='robots':self.robots=a.get('content','')
  if tag=='nav' and a.get('aria-label')=='현재 위치':self.nav=1
  if self.nav and tag=='a':self.anchor=[a.get('href',''),'']
 def handle_data(self,s):
  if self.cap=='title':self.title+=s
  if self.cap=='h1':self.h1+=s
  if self.anchor is not None:self.anchor[1]+=s
 def handle_endtag(self,t):
  if t==self.cap:self.cap=None
  if t=='a' and self.anchor is not None:self.crumbs.append(self.anchor);self.anchor=None
  if t=='nav':self.nav=0

def render(src,rel):
 clean=re.sub(r'<!-- seo-v86 start -->.*?<!-- seo-v86 end -->','',src,flags=re.S)
 t=Tags();t.feed(clean)
 if 'noindex' in t.robots.lower() or rel=='404.html':return clean,False
 title=' '.join(t.title.split());name=' '.join(t.h1.split()) or title
 if not title or not name:raise ValueError('Missing title/heading: '+rel)
 url=BASE+('/' if rel=='index.html' else '/'+rel)
 desc=' '.join(t.desc.split())
 if not desc:desc=name+'의 자료와 원문 연결 경로를 확인하세요.'
 can='<link rel="canonical" href="'+escape(url,quote=True)+'">'
 clean=re.sub(r'<link\b(?=[^>]*\brel=[\"\x27]canonical[\"\x27])[^>]*>', '',clean, flags=re.I)
 if not t.desc:clean=clean.replace('</head>','<meta name="description" content="'+escape(desc,quote=True)+'"></head>',1)
 graph=[]
 page={'@type':'CollectionPage' if rel.startswith('manufacturer') else 'WebPage','@id':url+'#webpage','url':url,'name':name,'description':desc,'inLanguage':'ko','isPartOf':{'@id':BASE+'/#website'}}
 if rel=='index.html':graph.append({'@type':'WebSite','@id':BASE+'/#website','url':BASE+'/','name':'MSDS 모아','inLanguage':'ko'})
 trail=[]
 for href,label in t.crumbs:
  u=urljoin(url,href);label=' '.join(label.split())
  if label and u.startswith(BASE+'/') and u!=url and u not in [v[0] for v in trail]:trail.append((u,label))
 if trail:
  trail.append((url,name));bid=url+'#breadcrumb';page['breadcrumb']={'@id':bid};graph.append({'@type':'BreadcrumbList','@id':bid,'itemListElement':[{'@type':'ListItem','position':i+1,'name':n,'item':u} for i,(u,n) in enumerate(trail)]})
 graph.append(page);data=json.dumps({'@context':'https://schema.org','@graph':graph},ensure_ascii=False,separators=(',',':')).replace('<',chr(92)+'u003c')
 block='<!-- seo-v86 start -->'+can+'<script type="application/ld+json" id="seo-v86">'+data+'</script><!-- seo-v86 end -->'
 return clean.replace('</head>',block+'</head>',1),bool(trail)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();stats={'html_checked':0,'files_changed':0,'breadcrumb_pages':0}
 for f in sorted(a.site.rglob('*.html')):
  if any(x in ('backup','.git') for x in f.relative_to(a.site).parts):continue
  s=f.read_text(encoding='utf-8');rel=f.relative_to(a.site).as_posix();out,crumb=render(s,rel);stats['html_checked']+=1;stats['breadcrumb_pages']+=int(crumb)
  if out!=s:
   b=a.backup/rel;b.parent.mkdir(parents=True,exist_ok=True)
   if not b.exists():shutil.copy2(f,b)
   f.write_text(out,encoding='utf-8');stats['files_changed']+=1
 if stats['files_changed'] or not (a.site/'seo-report-v86.json').exists():(a.site/'seo-report-v86.json').write_text(json.dumps(stats,indent=2))
 print('SEO V86 COMPLETE',json.dumps(stats))
if __name__=='__main__':main()
