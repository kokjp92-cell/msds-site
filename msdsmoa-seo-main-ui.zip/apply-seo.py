from pathlib import Path
from collections import defaultdict
import hashlib
import html
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
home = root / "index.html"
if not home.is_file():
    raise SystemExit("index.html not found")
source = home.read_text(encoding="utf-8")
if 'msds-seo-v1' in source:
    raise SystemExit("SEO patch already applied. No changes.")
scripts = list(re.finditer(r'<script\b([^>]*)>(.*?)</script>', source, re.S))
candidates = [m for m in scripts if not re.search(r'\bsrc\s*=',m.group(1)) and 'function productRow(product)' in m.group(2)]
if len(candidates) != 1:
    raise SystemExit("Unexpected home search structure. No changes.")
match = candidates[0]
bundle = match.group(2)
anchor = "  return row;\n}"
if bundle.count(anchor) != 1:
    raise SystemExit("Unexpected product renderer. No changes.")
bundle = bundle.replace(anchor, """  const detailKey = JSON.stringify([product.company, product.name]);
  const detailPath = window.msdsDetailIndex?.[detailKey];
  if (detailPath) {
    const detailLink = element('a', '제품 상세보기 →', 'product-detail-link');
    detailLink.href = detailPath;
    details.append(detailLink);
  }
  return row;
}""",1)

def text(value):
    return html.unescape(re.sub(r'<[^>]*>', '',value)).strip()

def atomic(path, value):
    temporary = path.with_name(path.name + ".seo-tmp")
    try:
        temporary.write_text(value,encoding="utf-8")
        if path.exists():
            import shutil
            shutil.copystat(path,temporary)
        else:
            temporary.chmod(0o644)
        os.replace(temporary,path)
    finally:
        temporary.unlink(missing_ok=True)

index = defaultdict(set)
detail_pages = list((root / "products").glob("*.html"))
for page in detail_pages:
    content = page.read_text(encoding="utf-8")
    values = re.findall(r'<dd\b[^>]*>(.*?)</dd>',content,re.S)
    if len(values) >= 2:
        key = json.dumps([text(values[1]),text(values[0])],ensure_ascii=False,separators=(',',':'))
        index[key].add('/'+page.relative_to(root).as_posix())
mapping = {key:next(iter(paths)) for key,paths in index.items() if len(paths)==1}
if not mapping:
    raise SystemExit("No verified detail mappings. No changes.")

links = []
for page in sorted(root.glob("manufacturer-*.html")):
    if re.search(r'-\d+\.html$',page.name):
        continue
    content = page.read_text(encoding="utf-8")
    title = re.search(r'<title>(.*?)</title>',content,re.S)
    label = text(title.group(1)).split(' MSDS')[0] if title else page.stem
    links.append('<a href="/'+page.name+'">'+html.escape(label)+'</a>')
hub = '<div class="seo-maker-links"><p>제조사별 자료실에서 제품 상세정보와 공식 MSDS를 확인하세요.</p>'+ ' · '.join(links)+'</div>'
pattern = r'(<section\b[^>]*\bid=["\x27]results["\x27][^>]*>).*?(</section>)'
source, count = re.subn(pattern,lambda m:m.group(1)+hub+m.group(2),source,count=1,flags=re.S)
if count!=1:
    raise SystemExit("Results container not found. No changes.")
bundle_hash=hashlib.sha256(bundle.encode()).hexdigest()[:12]
map_script='window.msdsDetailIndex='+json.dumps(mapping,ensure_ascii=False,separators=(',',':'))+';'
map_hash=hashlib.sha256(map_script.encode()).hexdigest()[:12]
assets=root/'assets'
assets.mkdir(exist_ok=True)
bundle_name='home-search-'+bundle_hash+'.js'
map_name='detail-index-'+map_hash+'.js'
atomic(assets/bundle_name,bundle)
atomic(assets/map_name,map_script)
replacement='<script src="/assets/'+map_name+'" defer></script><script src="/assets/'+bundle_name+'" defer></script><!-- msds-seo-v1 -->'
source=re.sub(r'<script\b[^>]*>.*?</script>',lambda m:replacement if 'function productRow(product)' in m.group(0) else m.group(0),source,flags=re.S)
style='<style>.product-detail-link{display:inline-block;margin-top:10px;font-size:14px;font-weight:600}.seo-maker-links{padding:18px;line-height:2}.seo-maker-links a{display:inline-block;margin-right:12px}</style>'
source=source.replace('<title>',style+'<title>',1)
atomic(home,source)

namespace='http://www.sitemaps.org/schemas/sitemap/0.9'
ET.register_namespace('',namespace)
tree=ET.Element('{'+namespace+'}urlset')
urls=set()
for page in root.rglob('*.html'):
    if page.is_symlink() or any(part.startswith('.') for part in page.relative_to(root).parts):
        continue
    content=page.read_text(encoding="utf-8")
    if re.search(r'<meta\b[^>]*name=["\x27]robots["\x27][^>]*noindex',content,re.I):
        continue
    canonical=re.search(r'<link\b(?=[^>]*\brel=["\x27]canonical["\x27])[^>]*\bhref=["\x27]([^"\x27]+)',content,re.I)
    relative=page.relative_to(root).as_posix()
    if relative in ['404.html','error.html']:
        continue
    url=html.unescape(canonical.group(1)) if canonical else 'https://msdsmoa.com/'+('' if relative=='index.html' else relative)
    if url.startswith('https://msdsmoa.com/'):
        urls.add(url.split('#')[0])
for url in sorted(urls):
    node=ET.SubElement(tree,'{'+namespace+'}url')
    ET.SubElement(node,'{'+namespace+'}loc').text=url
if len(urls)>50000:
    raise SystemExit("Sitemap exceeds 50,000 URLs. Split required.")
atomic(root/'sitemap.xml',ET.tostring(tree,encoding='unicode',xml_declaration=True))
print(f"SEO COMPLETE: {len(mapping)} unique product mappings, {len(urls)} sitemap URLs")
print(f"Home HTML: {len(source.encode()):,} bytes")
