"""Verify every local HTML internal href/src, fragment and active data mapping without network access."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,urljoin,unquote
import argparse,json,re,posixpath,hashlib
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);a=ap.parse_args();site=a.site;allfiles={p.relative_to(site).as_posix() for p in site.rglob('*') if p.is_file()};pages={};links=[];errors=[];count=0;contexts=0
class Page(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.ids=set();self.links=[]
 def handle_starttag(self,t,attrs):
  z=dict(attrs)
  if z.get('id'):self.ids.add(z['id'])
  if t=='a' and z.get('name'):self.ids.add(z['name'])
  if t=='a' and z.get('href'):self.links.append(('href',z['href']))
  if t in ('script','img','source','iframe') and z.get('src'):self.links.append(('src',z['src']))
  if t=='link' and z.get('rel') in ('stylesheet','icon','apple-touch-icon','manifest') and z.get('href'):self.links.append(('asset',z['href']))
for rel in sorted(x for x in allfiles if x.endswith('.html') and not any(p in ('backup','.git') for p in Path(x).parts)):
 p=Page();p.feed((site/rel).read_text());pages[rel]=p.ids
 for kind,raw in p.links:
  u=urlsplit(urljoin('https://msdsmoa.com/'+rel,raw))
  if u.scheme not in ('http','https') or u.hostname not in ('msdsmoa.com','www.msdsmoa.com'):continue
  dest=posixpath.normpath(unquote(u.path)).lstrip('/')
  if not dest or dest=='.':dest='index.html'
  elif u.path.endswith('/'):dest+='/index.html'
  links.append((rel,kind,raw,dest,unquote(u.fragment)));count+=1
context_handler=(site/'msds-document-context-v55.js').read_text() if 'msds-document-context-v55.js' in allfiles else ''
for rel,kind,raw,dest,fragment in links:
 if dest not in allfiles:errors.append(dict(page=rel,issue='missing_internal_target',target=raw));continue
 if fragment and kind=='href' and dest in pages and fragment not in pages[dest]:
  if dest=='msds-document-check.html' and fragment.startswith('document='):
   try:
    raw_fragment=urlsplit(urljoin('https://msdsmoa.com/'+rel,raw)).fragment[len('document='):]
    if len(raw_fragment)>12000:raise ValueError('context length exceeds supported maximum')
    data=json.loads(unquote(raw_fragment))
    if not isinstance(data,dict) or any(k in data and (not isinstance(data[k],str) or len(data[k])>4000) for k in ('company','name','url')):raise ValueError('invalid supported context fields')
    if '#document=' not in context_handler:raise ValueError('context handler missing')
    contexts+=1
   except Exception as e:errors.append(dict(page=rel,issue='invalid_document_context',target=raw,reason=str(e)))
  else:errors.append(dict(page=rel,issue='missing_fragment',target=raw))
h=(site/'index.html').read_text();jsfile=re.search('id="msds-search-bundle" content="([^"]+)"',h)[1];js=(site/jsfile[1:]).read_text();ixfile=re.search('id="msds-detail-index" content="([^"]+)"',h)[1];ix=json.loads((site/ixfile[1:]).read_text().removeprefix('window.msdsDetailIndex=').strip().removesuffix(';'));manifest=json.loads(re.search(r'^const manufacturerDetailFiles = (.*);$',js,re.M)[1]);mapped=0
for company,path in manifest.items():
 f=site/path[1:]
 if not f.is_file():errors.append(dict(issue='missing_company_mapping',company=company,path=path));continue
 data=json.loads(f.read_text());expected={k:v for k,v in ix.items() if json.loads(k)[0]==company}
 if data!=expected:errors.append(dict(issue='company_mapping_differs',company=company,path=path))
 mapped+=len(data)
report=dict(scope='Every local HTML href/src and fragment, plus all active manufacturer/detail mappings; external document responses excluded.',summary=dict(html_checked=len(pages),internal_links_checked=count,document_context_fragments_checked=contexts,company_maps_checked=len(manifest),company_map_records_checked=mapped,errors=len(errors)),errors=errors)
out=site/'all-internal-links-audit-v92.json';raw=json.dumps(report,ensure_ascii=False,indent=2)
if not out.exists() or out.read_text()!=raw:out.write_text(raw)
print(json.dumps(report['summary'],ensure_ascii=False));raise SystemExit(bool(errors))
