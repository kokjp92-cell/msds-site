"""Defer the MSDS detail index until the visitor opens a result group."""
import argparse
import hashlib
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise SystemExit(f"Unexpected site structure near {old[:100]!r}. No changes made.")
    return source.replace(old, new, 1)


def install(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as file:
        temporary = Path(file.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
if 'id="msds-detail-index"' in html:
    raise SystemExit("Home performance patch already applied.")
detail = re.search(r'<script src="(/assets/detail-index-[a-f0-9]+\.js)" defer></script>', html)
search = re.search(r'<script src="(/assets/home-search-[a-f0-9]+\.js)" defer></script>', html)
if not detail or not search or not (args.site / detail[1][1:]).is_file():
    raise SystemExit("Expected home search and detail index assets. No changes made.")
bundle = (args.site / search[1][1:]).read_text(encoding="utf-8")
loader = """let detailIndexRequest;
function loadDetailIndex() {
  if (window.msdsDetailIndex) return Promise.resolve(window.msdsDetailIndex);
  if (!detailIndexRequest) {
    detailIndexRequest = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = document.getElementById('msds-detail-index').content;
      script.onload = () => window.msdsDetailIndex
        ? resolve(window.msdsDetailIndex) : reject(new Error('Invalid detail index'));
      script.onerror = () => reject(new Error('Could not load detail index'));
      document.head.append(script);
    }).catch(() => {
      detailIndexRequest = undefined;
      return null;
    });
  }
  return detailIndexRequest;
}

"""
bundle = replace_once(bundle, "function productRow(product) {", loader + "function productRow(product) {")
old = """  const detailKey = JSON.stringify([product.company, product.name]);
  const detailPath = window.msdsDetailIndex?.[JSON.stringify([product.company, product.name, product.url])] || window.msdsDetailIndex?.[detailKey];
  if (detailPath) {
    const detailLink = element('a', '제품 상세보기 →', 'product-detail-link');
    detailLink.href = detailPath;
    details.append(detailLink);
  }"""
new = """  function addDetailLink(index) {
    const detailKey = JSON.stringify([product.company, product.name]);
    const detailPath = index?.[JSON.stringify([product.company, product.name, product.url])] || index?.[detailKey];
    if (detailPath) {
      const detailLink = element('a', '제품 상세보기 →', 'product-detail-link');
      detailLink.href = detailPath;
      details.append(detailLink);
    }
  }
  if (window.msdsDetailIndex) addDetailLink(window.msdsDetailIndex);
  else loadDetailIndex().then(addDetailLink);"""
bundle = replace_once(bundle, old, new)
asset = "/assets/home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
html = replace_once(html, detail[0], f'<meta id="msds-detail-index" content="{detail[1]}">')
html = replace_once(html, search[1], asset)
args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
install(args.site / asset[1:], bundle, 0o644)
install(home, html, home.stat().st_mode)
print(f"HOME PERFORMANCE COMPLETE\nBackup: {args.backup / home.name}")
