from pathlib import Path
from urllib.parse import urlparse, urlencode
from html import escape, unescape
import hashlib
import json
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
data = json.loads(Path(__file__).with_name("ssangkom-products.json").read_text())
home = root / "index.html"
directory = root / "manufacturers.html"
source = home.read_text()
match = re.search(r'<script src="(/assets/home-search-[a-f0-9]+\.js)" defer></script>', source)
if not match:
    raise SystemExit("Search bundle not found. No changes.")
bundle = (root / match.group(1).lstrip("/")).read_text()
if "ssangkom-documents-v1" in bundle:
    print("쌍곰 patch already applied.")
    raise SystemExit(0)
anchor = "const results = document.querySelector('#results');"
if bundle.count(anchor) != 1:
    raise SystemExit("Unexpected search structure. No changes.")

def key(url):
    parsed = urlparse(unescape(url))
    return parsed.path

existing = {key(url) for url in re.findall(r'https?://(?:www\.)?ssangkom\.co\.kr/data/document/[^"\s<>]+\.pdf', bundle)}
fresh = [row for row in data if key(row["url"]) not in existing]
official = "https://ssangkom.co.kr/description/data.php?categories_all=1"
records = [
    {"company": "쌍곰", "name": row["name"],
     "keywords": "쌍곰 SSANGKOM " + row["name"] + " " + row["code"],
     "url": row["url"], "verifiedList": official,
     "detail": "제조사 공식 MSDS · PDF",
     "label": "MSDS PDF 열기 ↗",
     "instructions": "PDF 원문에서 제품명·언어·개정일을 확인하세요."}
    for row in fresh
]
bundle = bundle.replace(anchor, "// ssangkom-documents-v1\nproducts.push(..." + json.dumps(records, ensure_ascii=False) + ");\n" + anchor, 1)
totals = set(re.findall(r'등록 자료 ([\d,]+)건', bundle))
if len(totals) == 1:
    old = totals.pop()
    new = f"{int(old.replace(',', '')) + len(fresh):,}"
    bundle = bundle.replace(old + "건", new + "건")
    source = source.replace(old + "건", new + "건")
bundle_name = "home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
source = source.replace(match.group(1), "/assets/" + bundle_name, 1)
directory_html = directory.read_text()
base = "manufacturer-ssangkom"
filename = base + ".html"
page = (root / filename).read_text()
section = re.search(r'(<section aria-labelledby="catalog-heading">)(.*?)(</section>)', page, re.S)
if not section:
    raise SystemExit("Manufacturer catalog structure not found. No changes.")
old_cards = section[2]
known_paths = {key(url) for url in re.findall(r'https?://(?:www\.)?ssangkom\.co\.kr/data/document/[^"\s<>]+\.pdf', old_cards)}
cards = []
for row in data:
    if key(row["url"]) in known_paths:
        continue
    name = escape(row["name"])
    url = escape(row["url"], quote=True)
    code = escape(row["code"])
    terms = escape(f'{row["name"]} 쌍곰 ssangkom {row["code"]}'.lower(), quote=True)
    report = escape(urlencode({"company": "쌍곰", "product": row["name"], "link": row["url"]}), quote=True)
    cards.append(
        f'<article class="row catalog-item" data-search="{terms}"><div>'
        f'<div class="status">쌍곰 · 공식 MSDS · 문서 {code} · PDF</div><h3>{name}</h3>'
        f'<span class="download-kind kind-pdf">PDF</span>'
        f'<a class="report-link" href="feedback.html?{report}">이 자료의 링크 오류 제보</a></div>'
        f'<div class="result-actions"><a class="action" href="{url}" target="_blank" rel="noopener noreferrer">MSDS PDF 열기 ↗</a></div></article>'
    )
count = old_cards.count('class="row catalog-item"') + len(cards)
page = page[:section.end(2)] + "\n".join(cards) + page[section.end(2):]
if (root / "site-width-960.css").is_file() and "/site-width-960.css" not in page:
    page = page.replace("</head>", '<link rel="stylesheet" href="/site-width-960.css"></head>', 1)
page = re.sub(r'쌍곰 MSDS 일부 [\d,]+건의', f'쌍곰 MSDS {count:,}건의', page)
page = re.sub(r'등록 자료 [\d,]+건', f'등록 자료 {count:,}건', page)
page = re.sub(r'1–[\d,]+번째 자료', f'1–{count:,}번째 자료', page)
page = re.sub(r'(?<=문서 )[\d,]+(?=건)', str(count), page)
page = page.replace('현재 페이지에 표시된 자료만 검색합니다. 다른 페이지는 아래 페이지 번호로 이동하세요.', '제품명이나 문서 번호로 검색할 수 있습니다.')
page = page.replace('나머지 자료는 공식 자료실을 이용하세요.</p>', f'나머지 자료는 공식 자료실을 이용하세요.</p><p><a href="{official}" target="_blank" rel="noopener noreferrer">쌍곰 공식 MSDS 자료실 ↗</a></p>')
directory_card = re.search(r'<article class="row">(?:(?!</article>).)*href="/?manufacturer-ssangkom\.html"(?:(?!</article>).)*</article>', directory_html, re.S)
if not directory_card or not re.search(r'등록 자료 [\d,]+건', directory_card[0]):
    raise SystemExit("Manufacturer directory entry not found. No changes.")
card = re.sub(r'등록 자료 [\d,]+건', f'등록 자료 {count:,}건', directory_card[0])
directory_html = directory_html[:directory_card.start()] + card + directory_html[directory_card.end():]
filenames = [filename]
outputs = {root / filename: page}
tree = ET.parse(root / "sitemap.xml")
namespace = "http://www.sitemaps.org/schemas/sitemap/0.9"
ET.register_namespace("", namespace)
known = {node.text for node in tree.findall(f".//{{{namespace}}}loc")}
for name in filenames:
    url = "https://msdsmoa.com/" + name
    if url not in known:
        node = ET.SubElement(tree.getroot(), f"{{{namespace}}}url")
        ET.SubElement(node, f"{{{namespace}}}loc").text = url
if len(tree.getroot()) > 50000:
    raise SystemExit("Sitemap limit exceeded. No changes.")
outputs[root / "assets" / bundle_name] = bundle
outputs[root / "sitemap.xml"] = ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True)
outputs[directory] = directory_html
outputs[home] = source
for path, content in outputs.items():
    temporary = path.with_name(path.name + ".ssangkom-tmp")
    try:
        temporary.write_text(content, encoding="utf-8")
        if path.exists():
            shutil.copystat(path, temporary)
        else:
            temporary.chmod(0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
print(f"쌍곰 COMPLETE: {len(fresh)} new documents; {len(data) - len(fresh)} existing documents skipped; {len(filenames)} listing pages")
