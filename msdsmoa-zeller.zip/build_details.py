import hashlib
import json
import re
import xml.etree.ElementTree as ET
from html import escape, unescape
from pathlib import Path

def prepare_details(root, source, page, tree, rows):
    company = '뉴젠텍루브켐'
    directory = '/manufacturer-zeller.html'
    package = Path(__file__).resolve().parent
    template = (package / 'detail-template.html').read_text()
    asset = re.search(r'/assets/detail-index-[a-f0-9]+\.js', source)
    if not asset:
        raise SystemExit('Home detail index not found.')
    prefix = 'window.msdsDetailIndex='
    raw = (root / asset[0].lstrip('/')).read_text().strip()
    if not raw.startswith(prefix):
        raise SystemExit('Unexpected detail index format.')
    index = json.loads(raw[len(prefix):].rstrip(';'))
    ns = 'http://www.sitemaps.org/schemas/sitemap/0.9'
    known = {node.text for node in tree.findall(f'.//{{{ns}}}loc')}
    outputs = {}
    links = {}
    for row in rows:
        name = row['name']
        key = json.dumps([company, name], ensure_ascii=False, separators=(',', ':'))
        slug = hashlib.sha256(key.encode()).hexdigest()[:24]
        path = index.get(key, f'/products/{slug}.html')
        if not re.fullmatch(r'/products/[a-zA-Z0-9_-]+\.html', path):
            raise SystemExit(f'Invalid detail path: {path}')
        canonical = 'https://msdsmoa.com' + path
        fields = {'TITLE': f'{company} {name} MSDS',
                  'DESCRIPTION': f'{company} {name} MSDS 공식 게시글.',
                  'CANONICAL': canonical, 'NAME': name, 'PDF': row['url'], 'COMPANY': company,
                  'CATALOG': directory, 'SOURCE': row['source'],
                  'FORMAT': '공식 게시글', 'BUTTON': '공식 MSDS 게시글 보기 ↗', 'FILES': ', '.join(row['files']) or '공식 게시글에서 확인'}
        target = root / path.lstrip('/')
        if not target.is_file():
            content = re.sub(r'\{\{([A-Z]+)\}\}', lambda match: escape(fields[match[1]], quote=True), template)
            if (root / 'site-width-960.css').is_file():
                content = content.replace('</head>', '<link rel="stylesheet" href="/site-width-960.css"></head>', 1)
            outputs[target] = content
        index[key] = path
        links[name] = path
        if canonical not in known:
            node = ET.SubElement(tree.getroot(), f'{{{ns}}}url')
            ET.SubElement(node, f'{{{ns}}}loc').text = canonical
            known.add(canonical)
    if len(tree.getroot()) > 50000:
        raise SystemExit('Sitemap URL limit exceeded.')

    linked = set()
    def link_title(match):
        name = unescape(match[1])
        if name not in links:
            return match[0]
        linked.add(name)
        return f'<h3><a href="{links[name]}">{escape(name)}</a></h3>'

    page = re.sub(r'<h3>([^<]+)</h3>', link_title, page)
    if linked != links.keys():
        raise SystemExit('Missing titles in manufacturer catalog.')
    outputs[root / directory.lstrip('/')] = page
    index_js = prefix + json.dumps(index, ensure_ascii=False, separators=(',', ':')) + ';\n'
    index_path = '/assets/detail-index-' + hashlib.sha256(index_js.encode()).hexdigest()[:12] + '.js'
    outputs[root / index_path.lstrip('/')] = index_js
    return source.replace(asset[0], index_path, 1), outputs
