"""Remove the standalone calcium topic link from the home page."""
import argparse,re,hashlib,shutil,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('site',type=Path);p.add_argument('--backup',type=Path,required=True);a=p.parse_args()
f=a.site/'index.html';s=f.read_text(encoding='utf-8')
pattern=r'<p\b(?=[^>]*\bid=["\']calcium-chloride-topic-link["\'])[^>]*>\s*<a\b[^>]*href=["\']/calcium-chloride-msds\.html["\'][^>]*>.*?</a>\s*</p>'
t,n=re.subn(pattern,'',s,flags=re.S)
if not n:
 if 'calcium-chloride-topic-link' in s:raise SystemExit('Home link structure differs; no changes made.')
 print('HOME TOPIC LAYOUT ALREADY CLEAN');raise SystemExit(0)
if n!=1:raise SystemExit('Expected one standalone home link; no changes made.')
if not (a.site/'calcium-chloride-msds.html').is_file():raise SystemExit('Topic page missing; no changes made.')
a.backup.mkdir(parents=True,exist_ok=False);shutil.copy2(f,a.backup/'index.html')
with tempfile.NamedTemporaryFile(dir=f.parent,delete=False) as h:tmp=Path(h.name)
try:
 tmp.write_text(t,encoding='utf-8');tmp.chmod(f.stat().st_mode & 0o777);tmp.replace(f)
finally:tmp.unlink(missing_ok=True)
print('HOME TOPIC LAYOUT COMPLETE');print('Backup:',a.backup/'index.html')
