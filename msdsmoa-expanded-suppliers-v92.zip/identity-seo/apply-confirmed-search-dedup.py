import argparse,json,re,hashlib,shutil
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();root=a.site;home=root/'index.html';h=home.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];s=(root/old[1:]).read_text();keys=json.loads((Path(__file__).parent/'confirmed-search-duplicates.json').read_text())
if '// confirmed-search-dedup-v91' not in s:
 marker='let previousResultsQuery;';assert marker in s;s=s.replace(marker,'const confirmedDuplicateKeysV91 = '+json.dumps(keys,ensure_ascii=False)+';\n'+marker)
 line='const matches = products.filter(product => (!fuelOnly || fuelTypeFor(product.company, product.name) === requestedFuel) && terms.every(term => matchesSearchTerm(product, term)));';assert line in s
 new='''const seenConfirmedDocuments = new Set();
  const matches = products.filter(product => {
    if ((fuelOnly && fuelTypeFor(product.company, product.name) !== requestedFuel) || !terms.every(term => matchesSearchTerm(product, term))) return false;
    const identity = confirmedDuplicateKeysV91[JSON.stringify([product.company, product.name, product.url])];
    if (!identity) return true;
    const attachments = JSON.stringify((product.additionalDownloads || []).map(d => [d.language || '', d.url]).sort((a,b) => JSON.stringify(a).localeCompare(JSON.stringify(b))));
    const key = identity + '|' + attachments;
    if (seenConfirmedDocuments.has(key)) return false;
    seenConfirmedDocuments.add(key);
    return true;
  });'''
 s=s.replace(line,new);s+='\n// confirmed-search-dedup-v91\n'
else:s=re.sub(r'^const confirmedDuplicateKeysV91 = .*;$','const confirmedDuplicateKeysV91 = '+json.dumps(keys,ensure_ascii=False)+';',s,flags=re.M)
if s!=(root/old[1:]).read_text():
 new='/assets/home-search-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js';(root/new[1:]).write_text(s);a.backup.mkdir(parents=True,exist_ok=True)
 if not (a.backup/'index.html').exists():shutil.copy2(home,a.backup/'index.html')
 home.write_text(h.replace(old,new))
print('CONFIRMED SEARCH DEDUP V91',len(keys),'record identities; differing language attachments preserved')
