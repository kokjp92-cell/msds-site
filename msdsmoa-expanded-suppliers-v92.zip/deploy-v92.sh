#!/usr/bin/env bash
set -eu
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
site_dir=${1:-/var/www/msdsmoa}
backup_dir=${2:-$(mktemp -d /home/ubuntu/msdsmoa-v92-backup.XXXXXX)}
echo "Backup: $backup_dir"
mkdir -p "$backup_dir"
python3 - "$site_dir" "$backup_dir" <<'PY_CHECK'
from pathlib import Path
import sys
site, backup = map(lambda s: Path(s).resolve(), sys.argv[1:])
if not site.is_dir() or backup.is_relative_to(site):
    raise SystemExit("Site must exist and backup must be outside the site directory.")
PY_CHECK
if [ -e "$backup_dir/site-before-v92.tar.gz" ]; then
  echo "Existing full backup found; choose a new backup directory."
  exit 1
fi
tar -czf "$backup_dir/site-before-v92.tar.gz" -C "$site_dir" .

python3 "$package_dir/apply-expanded-suppliers.py" "$site_dir" --backup "$backup_dir"
python3 "$package_dir/sitewide-quality/verify-sitewide-quality.py" "$site_dir"
echo 'V92 LOCAL DEPLOY VERIFY OK'
echo "Backup: $backup_dir"
echo 'Reports: /seo-duplicate-report-v92.json /source-detail-audit-v92.json /all-internal-links-audit-v92.json'
