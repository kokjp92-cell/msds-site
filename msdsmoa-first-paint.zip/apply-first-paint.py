"""Inline the small first-party stylesheets used by the home page."""
import argparse
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
if 'id="msds-home-inline-site-ui"' in html:
    print("First paint patch already applied.")
    raise SystemExit(0)

for name in ("site-ui", "site-clean"):
    link = re.search(rf'<link rel="stylesheet" href="/?{name}\.css(?:\?[^"]+)?">', html)
    if not link:
        raise SystemExit(f"Expected the home {name} stylesheet. No changes made.")
    css = (args.site / f"{name}.css").read_text(encoding="utf-8")
    if not css.strip() or re.search(r'@(?:import|charset)\b|url\s*\(|</style', css, re.I):
        raise SystemExit(f"The {name} stylesheet requires a separate URL. No changes made.")
    html = replace_once(html, link[0], f'<style id="msds-home-inline-{name}">\n{css}\n</style>')

args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
publish(home, html, home.stat().st_mode)
print(f"FIRST PAINT COMPLETE\nBackup: {args.backup / home.name}")
