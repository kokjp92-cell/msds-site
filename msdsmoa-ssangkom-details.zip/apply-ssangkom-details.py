import hashlib
import json
import os
import re
import sys
import tempfile
import xml.etree.ElementTree as ET
from html import escape, unescape
from pathlib import Path

root = Path(sys.argv[1]).resolve()
package = Path(__file__).resolve().parent
company = '쌍곰'
catalog_name = 'manufacturer-ssangkom.html'
catalog = root / catalog_name
page = catalog.read_text()
rows = json.loads((package / 'ssangkom-products.json').read_text())
by_url = {row['url']: row for row in rows}
template = (package / 'detail-template.html').read_text()
home = root / 'index.html'
sitemap = root / 'sitemap.xml'
home_html = home.read_text()
asset = re.search(r'/assets/detail-index-[a-f0-9]+\.js', home_html)
search_asset = re.search(r'/assets/home-search-[a-f0-9]+\.js', home_html)
if not asset or not search_asset:
    raise SystemExit('Site assets not found.')
prefix = 'window.msdsDetailIndex='
index_source = (root / asset[0].lstrip('/')).read_text().strip()
if not index_source.startswith(prefix):
    raise SystemExit('Unexpected detail index format.')
index = json.loads(index_source[len(prefix):].rstrip(';'))
search = (root / search_asset[0].lstrip('/')).read_text()
original = 'const detailPath = window.msdsDetailIndex?.[detailKey];'
updated = ('const detailPath = window.msdsDetailIndex?.[JSON.stringify([product.company, product.name, product.url])] '
           '|| window.msdsDetailIndex?.[detailKey];')
if updated not in search:
    if search.count(original) != 1:
        raise SystemExit('Unexpected home search detail logic.')
    search = search.replace(original, updated)

ns = 'http://www.sitemaps.org/schemas/sitemap/0.9'
ET.register_namespace('', ns)
tree = ET.parse(sitemap)
known_urls = {node.text for node in tree.findall(f'.//{{{ns}}}loc')}
outputs = {}
linked = set()

def link_card(match):
    card = match[0]
    pdf = re.search(r'<a class="action" href="(https://ssangkom\.co\.kr/data/document/[^"]+\.pdf)"', card)
    title = re.search(r'<h3>(.*?)</h3>', card, re.S)
    if not pdf or not title:
        return card
    url = unescape(pdf[1])
    name = unescape(re.sub(r'<[^>]+>', '', title[1])).strip()
    key = json.dumps([company, name, url], ensure_ascii=False, separators=(',', ':'))
    current = re.search(r'href="(/?products/[a-zA-Z0-9_-]+\.html)"', title[1])
    if current:
        index[key] = '/' + current[1].lstrip('/')
        return card
    row = by_url.get(url)
    if not row:
        return card
    path = '/products/' + hashlib.sha256(key.encode()).hexdigest()[:24] + '.html'
    target = root / path.lstrip('/')
    canonical = 'https://msdsmoa.com' + path
    fields = {'TITLE': f'쌍곰 {name} MSDS · 문서 {row["code"]}',
              'DESCRIPTION': f'쌍곰 {name} MSDS 문서 {row["code"]} 및 제조사 공식 자료실.',
              'CANONICAL': canonical, 'NAME': name, 'PDF': url, 'COMPANY': company,
              'CATALOG': '/' + catalog_name, 'SOURCE': 'https://ssangkom.co.kr/description/data.php?categories_all=1',
              'FORMAT': 'MSDS · PDF · 문서 ' + row['code'], 'BUTTON': '공식 MSDS PDF 열기 ↗'}
    if not target.is_file():
        content = re.sub(r'\{\{([A-Z]+)\}\}', lambda m: escape(fields[m[1]], quote=True), template)
        if (root / 'site-width-960.css').is_file():
            content = content.replace('</head>', '<link rel="stylesheet" href="/site-width-960.css"></head>', 1)
        outputs[target] = content
    index[key] = path
    linked.add(url)
    if canonical not in known_urls:
        node = ET.SubElement(tree.getroot(), f'{{{ns}}}url')
        ET.SubElement(node, f'{{{ns}}}loc').text = canonical
        known_urls.add(canonical)
    return card[:title.start()] + f'<h3><a href="{path}">{escape(name)}</a></h3>' + card[title.end():]

page = re.sub(r'<article\b[^>]*class="[^"]*catalog-item[^"]*"[^>]*>.*?</article>', link_card, page, flags=re.S)
if not all(url in page for url in by_url):
    raise SystemExit('Apply the Ssangkom expansion first.')
if len(tree.getroot()) > 50000:
    raise SystemExit('Sitemap URL limit exceeded.')
outputs[catalog] = page

index_js = prefix + json.dumps(index, ensure_ascii=False, separators=(',', ':')) + ';\n'
index_path = '/assets/detail-index-' + hashlib.sha256(index_js.encode()).hexdigest()[:12] + '.js'
search_path = '/assets/home-search-' + hashlib.sha256(search.encode()).hexdigest()[:12] + '.js'
outputs[root / index_path.lstrip('/')] = index_js
outputs[root / search_path.lstrip('/')] = search
outputs[sitemap] = ET.tostring(tree.getroot(), encoding='unicode', xml_declaration=True)
outputs[home] = home_html.replace(asset[0], index_path, 1).replace(search_asset[0], search_path, 1)
for path, content in outputs.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as out:
        out.write(content)
    temporary = Path(out.name)
    try:
        temporary.chmod(path.stat().st_mode & 0o777 if path.exists() else 0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
print(f'SSANGKOM DETAILS COMPLETE: {len(linked)} new links')
