import argparse,json,re,collections
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse
class P(HTMLParser):
 def __init__(self):super().__init__();self.c=[];self.ds=[];self.ld=[];self.title='';self.h1=0;self.cap=False;self.buf=None;self.noindex=False
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='link' and a.get('rel')=='canonical':self.c.append(a.get('href'))
  if t=='meta' and a.get('name')=='description':self.ds.append(a.get('content',''))
  if t=='meta' and a.get('name')=='robots' and 'noindex' in a.get('content',''):self.noindex=True
  if t=='script' and a.get('id')=='seo-v86':self.buf=''
  if t=='title':self.cap=True
  if t=='h1':self.h1+=1
 def handle_data(self,s):
  if self.cap:self.title+=s
  if self.buf is not None:self.buf+=s
 def handle_endtag(self,t):
  if t=='title':self.cap=False
  if t=='script' and self.buf is not None:self.ld.append(json.loads(self.buf));self.buf=None
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);a=ap.parse_args();count=0;crumbs=0;errors=[];titles=collections.Counter();descs=collections.Counter()
for f in a.site.rglob('*.html'):
 rel=f.relative_to(a.site).as_posix()
 if any(x in ('backup','.git') for x in f.relative_to(a.site).parts):continue
 p=P();p.feed(f.read_text())
 if rel=='404.html' or p.noindex:continue
 expected='https://msdsmoa.com'+('/' if rel=='index.html' else '/'+rel)
 if p.c!=[expected] or len(p.ds)!=1 or not p.ds[0] or len(p.ld)!=1 or not p.title.strip() or p.h1!=1:errors.append(rel+': metadata')
 if not p.ld:continue
 for g in p.ld[0]['@graph']:
  if g['@type']=='BreadcrumbList':
   crumbs+=1;items=g['itemListElement']
   if len(items)<2 or [x['position'] for x in items]!=list(range(1,len(items)+1)):errors.append(rel+': breadcrumb')
   for x in items:
    target=a.site/('index.html' if urlparse(x['item']).path=='/' else urlparse(x['item']).path.lstrip('/'))
    if not target.exists():errors.append(rel+': missing breadcrumb '+x['item'])
 titles[p.title]+=1;descs[p.ds[0]]+=1;count+=1
print(json.dumps({'checked':count,'breadcrumbs':crumbs,'duplicate_title_groups':sum(v>1 for v in titles.values()),'duplicate_description_groups':sum(v>1 for v in descs.values()),'errors':errors[:30],'error_count':len(errors)},ensure_ascii=False))
raise SystemExit(bool(errors))
