MSDS 모아 누적 v88 / 2026-11-25
기존 v87와 모든 이전 MSDS 추가/SEO/검색 개선 포함. 신규자료 증가는 없음.
확인된 수정: 한양상사3건 HTTP200 파일없음 응답을 PDF다운로드로 안내하지 않고 공급사홈에서MSDS요청 안내로 변경. 기존제품상세주소는보존. 원문 파일이 복구됐다고 표시하지 않음. Kixx Hybrid0W-16, RD HD32(P) 각2페이지의 동일PDF SHA256대조후 대표주소통일 및 중복2개주소만사이트맵제외. 기존HTML/원문링크/주소매핑삭제하지않음. 이외1,581동명이름후보를자동병합하지않음. 배포메타데이터날짜수정.
외부표본120URL/51호스트: 재확인후PDF헤더104,파일없음3,기타HTML/게시글확인필요10,재시도503오류3. 전체45,149고유상세주소의 외부링크전수검사는아님. 모든PDF의성분/국문/개정일검증이아님. 자세한근거audit-fixes/reports/점검결과.txt,summary.json,duplicate-pdf-check.json참고.
공개서버점검시v83,검색gzip663123바이트/immutable캐시정상. 서버설정변경불필요.
배포후홈45,154건/자료실223개/사이트맵45,462URL예상. 새문서추가나기존기록삭제없음.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v88-backup
검증: python3 seo/verify-seo.py /var/www/msdsmoa
로컬1109HTML/1007제품상세검사. 3실패링크안내,2중복대표주소/JSONLD,사이트맵,기존주소매핑/나머지링크보존,검색회귀,JS문법,재실행안정성검사. 실서버전체검사는배포시수행.
서버배포및Search Console제출수행하지않음.
