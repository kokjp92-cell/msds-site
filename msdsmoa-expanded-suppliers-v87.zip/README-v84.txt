MSDS 모아 v84 / 2026-11-25
기존 v83 및 모든 이전분 포함 누적 패키지. 신규 한국이콜랩 10건: OASIS137G, NOVASANKR, ECOLAB ALCOHOL CLEANER, QSR SUPER CONTACT CLEANER, KAY5 SANITIZER, EASY CLEAN MULTI PURPOSE CLEANER, MIPKR, AC360K, AC300, ECO GLIDE S.
공식 자료 서버의 전체PDF 다운로드·제품명·회사·실제 개정일·해시 확인. 원본PDF 재배포하지 않고 공식 링크 제공. 모든 성분/유해성에 대한 기술 심사 아님. 원액·희석액을 별도 문서로 부풀리지 않고 파일별 1건으로 등록. 실제 납품 라벨과 대조 필요.
공개 보관본의 개정일 범위2019-2026. 오래된 문서는 현행성을 보증하지 않으며 공급자 최신본 확인 필요. NOVASAN2026-02-23, ALCOHOL CLEANER2026-02-13, AC3002026-04-28, ECO GLIDE S2026-01-23은 실제 원문 날짜 적용.
배포 후 홈45,149건 / 공급사223개 / 사이트맵45,459 URL / 제품 식별 설명405건 예상. 검색·상세·자료실·사이트맵·법령/보호구·제휴 고지 연결, 기존 데이터 보존 및 재실행 검사 통과. 로컬998개 부분 상세파일 검사이며 실서버 전체 검사는 별도.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v84-backup
배포 후 검사: python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
서버 배포 수행하지 않음. chemical-additions-v84.csv / verified-sources-v84.json 참고.
