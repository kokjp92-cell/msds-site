"""Load only the detail links for the requested manufacturer."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def asset(name, content, extension):
    digest = hashlib.sha256(content.encode()).hexdigest()[:12]
    return f"/assets/{name}-{digest}.{extension}"


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
search = re.search(r'<meta id="msds-search-bundle" content="(/assets/home-search-[a-f0-9]+\.js)">', html)
detail = re.search(r'<meta id="msds-detail-index" content="(/assets/detail-index-[a-f0-9]+\.js)">', html)
if not search or not detail:
    raise SystemExit("Expected the optimized home search and detail index. No changes made.")
bundle = (args.site / search[1][1:]).read_text(encoding="utf-8")
raw = (args.site / detail[1][1:]).read_text(encoding="utf-8").strip()
prefix = "window.msdsDetailIndex="
if not raw.startswith(prefix):
    raise SystemExit("Unexpected detail index format. No changes made.")

groups = defaultdict(dict)
index = json.loads(raw[len(prefix):].removesuffix(";"))
for key, destination in index.items():
    identity = json.loads(key)
    if not isinstance(identity, list) or len(identity) not in (2, 3) or not isinstance(identity[0], str):
        raise SystemExit(f"Unexpected detail key: {key!r}")
    if not isinstance(destination, str) or not re.fullmatch(r"/(?:products/)?[\w-]+\.html", destination):
        raise SystemExit(f"Unexpected detail URL: {destination!r}")
    groups[identity[0]][key] = destination

files = {}
manifest = {}
for company, entries in sorted(groups.items()):
    content = json.dumps(entries, ensure_ascii=False, separators=(",", ":"))
    url = asset("detail-company", content, "json")
    files[url] = content
    manifest[company] = url

loader = """// BEGIN MSDS manufacturer detail links
const manufacturerDetailSource = SOURCE;
const manufacturerDetailFiles = MANIFEST;
const manufacturerDetailRequests = new Map();
function loadManufacturerDetails(company) {
  // When a catalog update changes the source index, use its current links.
  if (document.getElementById('msds-detail-index').content !== manufacturerDetailSource) {
    return loadDetailIndex();
  }
  if (!Object.hasOwn(manufacturerDetailFiles, company)) return Promise.resolve(null);
  if (!manufacturerDetailRequests.has(company)) {
    const request = fetch(manufacturerDetailFiles[company])
      .then(response => {
        if (!response.ok) throw new Error('Could not load manufacturer detail links');
        return response.json();
      })
      .catch(() => {
        manufacturerDetailRequests.delete(company);
        return loadDetailIndex();
      });
    manufacturerDetailRequests.set(company, request);
  }
  return manufacturerDetailRequests.get(company);
}
// END MSDS manufacturer detail links"""
loader = loader.replace("SOURCE", json.dumps(detail[1])).replace("MANIFEST", json.dumps(manifest, ensure_ascii=False, separators=(",", ":")))
existing = re.search(r"// BEGIN MSDS manufacturer detail links\n.*?// END MSDS manufacturer detail links", bundle, re.S)
if existing:
    bundle = replace_once(bundle, existing[0], loader)
else:
    bundle = replace_once(bundle, "function productRow(product) {", loader + "\n\nfunction productRow(product) {")
    bundle = replace_once(bundle, "else loadDetailIndex().then(addDetailLink);",
                          "else loadManufacturerDetails(product.company).then(addDetailLink);")

url = asset("home-search", bundle, "js")
if url == search[1] and all((args.site / path[1:]).is_file() for path in files):
    print("Detail link patch already applied.")
    raise SystemExit(0)
html = replace_once(html, search[0], search[0].replace(search[1], url))
args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
for path, content in files.items():
    publish(args.site / path[1:], content, 0o644)
publish(args.site / url[1:], bundle, 0o644)
publish(home, html, home.stat().st_mode)
print(f"DETAIL LINKS COMPLETE: {len(index)} keys, {len(groups)} manufacturers\nBackup: {args.backup / home.name}")
