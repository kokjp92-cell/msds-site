from pathlib import Path
from html.parser import HTMLParser
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'locale-seo'))
from locale_fields import Card
from urllib.parse import urlparse,parse_qs
import argparse,json,re,unicodedata
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('report',type=Path);a=ap.parse_args();root=a.site;h=(root/'index.html').read_text();meta=lambda k:re.search('id="'+k+'" content="([^"]+)"',h)[1];js=(root/meta('msds-search-bundle')[1:]).read_text();ix=json.loads((root/meta('msds-detail-index')[1:]).read_text().removeprefix('window.msdsDetailIndex=').strip().removesuffix(';'));rows=[dict(company=r[0],name=r[1],url=r[2]) for r in json.loads(re.search(r'^const catalog = (.*);$',js,re.M)[1])]
for m in re.finditer(r'products\.push\(\.\.\.(\[.*\])\);',js):rows.extend(json.loads(m[1]))
for file,c in [('noroo-products.json','노루페인트'),('kcc-products.json','KCC'),('3m-products.json','한국쓰리엠'),('samhwa-products.json','삼화페인트')]:rows.extend(dict(r,company=c) for r in json.loads((root/file).read_text()))
companies={json.loads(k)[0] for k in ix};three=next((c for c in companies if c.startswith('한국쓰리')),None)
for r in rows:
 if r['company'].startswith('한국쓰리') and three:r['company']=three
compact=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'));norm=lambda s:re.sub(r'\s+','',unicodedata.normalize('NFC',s)).casefold();issues=json.loads((Path(__file__).resolve().parent.parent/'audit-fixes/link-issues.json').read_text());resolutions=json.loads((Path(__file__).parent/'source-resolutions.json').read_text());resolved={compact([r['company'],r['name'],r['registered_url']]):r['resolved_url'] for r in resolutions};cache={};errors=[];names=[];missing=[];lookup=0;guarded=0
for i,r in enumerate(rows):
 if i and i%5000==0:print('SOURCE ROWS',i,flush=True)
 c,n,u=r['company'],r['name'],r['url'];path=ix.get(compact([c,n,u])) or ix.get(compact([c,n]));ctx=dict(company=c,name=n,url=u,path=path)
 if not path or not (root/path[1:]).is_file():missing.append(ctx);continue
 if path not in cache:
  src=(root/path[1:]).read_text();m=re.search(r'<section\b[^>]*>.*?</section>',src,re.S);section=m[0] if m else src;cparser=Card();cparser.feed(src)
  class Links(HTMLParser):
   def __init__(self):super().__init__(convert_charrefs=True);self.links=[];self.current=None
   def handle_starttag(self,t,attrs):
    z=dict(attrs)
    if t=='a' and 'href' in z:self.current=dict(url=z['href'],label='')
   def handle_data(self,d):
    if self.current is not None:self.current['label']+=d
   def handle_endtag(self,t):
    if t=='a' and self.current is not None:self.links.append(self.current);self.current=None
  lp=Links();lp.feed(section);cache[path]=dict(props=cparser.props,h1=cparser.h1,links=lp.links)
 z=cache[path];hrefs=[x['url'] for x in z['links']]
 if norm(n) not in norm(z['props'].get('제품명','')+' '+z['h1']):names.append(dict(ctx,visible=z['props'],h1=z['h1']))
 if not re.match(r'^https?://',u,re.I):guarded+=1;continue
 expected=issues.get(u,resolved.get(compact([c,n,u]),u))
 if expected in hrefs:continue
 accepted=False
 if c=='HD현대오일뱅크':
  accepted=any(urlparse(v).hostname=='www.hyundaixteer.com' and urlparse(v).path=='/en/product/pdsMsds' and bool(parse_qs(urlparse(v).query).get('searchVal',[''])[0]) and norm(n).startswith(norm(parse_qs(urlparse(v).query).get('searchVal',[''])[0])) for v in hrefs)
 if c=='조선선재':accepted=any(urlparse(x['url']).hostname=='www.chosunwelding.com' and urlparse(x['url']).path=='/kr/Support/msds.asp' and '조회' in x['label'] for x in z['links'])
 if c=='헨켈 / LOCTITE':accepted=any(x['url']=='https://mysds.henkel.com/index.html' and '검색' in x['label'] for x in z['links'])
 if accepted:lookup+=1;continue
 errors.append(dict(ctx,expected=expected,current=z['links'],props=z['props']))

report=dict(summary=dict(source_rows=len(rows),detail_files_seen=len(cache),guarded_non_http=guarded,intentional_official_lookups=lookup,missing_files=len(missing),primary_link_mismatches=len(errors),registered_name_differences=len(names)),errors=errors,missing_files=missing,name_differences=names)
a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report['summary'],ensure_ascii=False),flush=True)

raise SystemExit(bool(errors or missing or names))
