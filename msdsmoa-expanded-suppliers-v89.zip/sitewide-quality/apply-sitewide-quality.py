#!/usr/bin/env python3
"""Enrich every registered product with grounded identity, navigation and comparison tools."""
import argparse,html,json,re,hashlib,os,shutil,tempfile,unicodedata
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,quote
from collections import defaultdict,Counter
P=argparse.ArgumentParser();P.add_argument('site',type=Path);P.add_argument('--backup',type=Path,required=True);a=P.parse_args();site=a.site.resolve();package=Path(__file__).resolve().parent
class Node:
 def __init__(self,tag='',attrs=(),parent=None):self.tag=tag;self.attrs=dict(attrs);self.children=[];self.parent=parent
 def text(self):return ' '.join(' '.join(x.text() if isinstance(x,Node) else x for x in self.children).split())
 def walk(self,tag=None):
  for x in self.children:
   if isinstance(x,Node):
    if tag is None or x.tag==tag:yield x
    yield from x.walk(tag)
class Doc(HTMLParser):
 def __init__(self,s):super().__init__(convert_charrefs=True);self.root=Node();self.cur=self.root;self.feed(s)
 def handle_starttag(self,t,attrs):
  n=Node(t,attrs,self.cur);self.cur.children.append(n)
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:self.cur=n
 def handle_startendtag(self,t,attrs):self.cur.children.append(Node(t,attrs,self.cur))
 def handle_endtag(self,t):
  n=self.cur
  while n.parent is not None:
   if n.tag==t:self.cur=n.parent;return
   n=n.parent
 def handle_data(self,s):self.cur.children.append(s)
def esc(s):return html.escape(str(s),quote=True)
def digest(b):return hashlib.sha256(b).hexdigest()
def read_index():
 home=(site/'index.html').read_text();d=Doc(home);m=next((n for n in d.root.walk('meta') if n.attrs.get('id')=='msds-detail-index'),None)
 if not m:raise ValueError('Detail index metadata missing. No pages updated.')
 path=m.attrs.get('content','');f=(site/path.lstrip('/')).resolve()
 if not f.is_relative_to(site):raise ValueError('Invalid detail-index path')
 raw=f.read_text().strip();prefix='window.msdsDetailIndex='
 if not raw.startswith(prefix):raise ValueError('Unsupported index format')
 data=json.loads(raw[len(prefix):].removesuffix(';'));byurl={};bycompany=defaultdict(list)
 for k,path in data.items():
  key=json.loads(k)
  if len(key)<2 or not path.startswith('/products/') or not path.endswith('.html'):continue
  old=byurl.get(path)
  if old and [re.sub(r'\s+',' ',str(x)).strip() for x in old[:2]]!=[re.sub(r'\s+',' ',str(x)).strip() for x in key[:2]]:raise ValueError('Conflicting product identities: '+path)
  byurl[path]=key
 for path,key in byurl.items():bycompany[key[0]].append((key[1],path))
 neighbours={}
 for company,items in bycompany.items():
  items.sort(key=lambda x:(unicodedata.normalize('NFKC',x[0]).casefold(),x[1]))
  for i,(name,path) in enumerate(items):neighbours[path]=[x for x in items[max(0,i-1):i+3] if x[1]!=path][:3]
 return byurl,bycompany,neighbours
index,companies,neighbours=read_index();files=sorted((site/'products').glob('*.html'))
if not files:raise SystemExit('No product detail pages found; no files changed.')
# Only pre-existing pages are updated. Missing indexed files are reported, never generated from guesses.
unknown=[str(f.relative_to(site)) for f in files if '/'+str(f.relative_to(site)) not in index]
# Older orphan detail files can exist outside the search index. Ground them in their
# visible product card and include them instead of silently skipping them.
original_index_count=len(index)
for rel in unknown:
 d=Doc((site/rel).read_text());main=next(d.root.walk('main'),None);section=next(main.walk('section'),None) if main else None
 if section is None:raise SystemExit('Unindexed detail has no product card; no sitewide writes: '+rel)
 pairs={};last=''
 for n in section.walk():
  if n.tag=='dt':last=n.text()
  if n.tag=='dd' and last:pairs[last]=n.text();last=''
 name=pairs.get('제품명','');company=next((v for k,v in pairs.items() if k in {'제조사','제조사·브랜드','원문 기재 업체','제조사·공급사'}),'')
 if not name or not company:raise SystemExit('Unindexed detail identity needs review; no sitewide writes: '+rel)
 path='/'+rel;index[path]=[company,name];companies[company].append((name,path));neighbours[path]=[]

a.backup.mkdir(parents=True,exist_ok=True);backup=Path(tempfile.mkdtemp(prefix='sitewide-quality-',dir=a.backup.resolve()));manifest=[]
integrity=Counter();link_samples=json.loads((package/'external-link-samples.json').read_text()) if (package/'external-link-samples.json').exists() else [];observations={x['url']:x for x in link_samples}
stats={'product_files':len(files),'products_enriched':0,'catalog_pages':0,'other_html_pages':0,'files_changed':0,'indexed_product_urls':original_index_count,'unindexed_product_files':len(unknown),'missing_indexed_files':len(set(index)-{'/'+str(f.relative_to(site)) for f in files})}
def write(f,s):
 raw=s.encode() if isinstance(s,str) else s;before=f.read_bytes() if f.exists() else None
 if before==raw:return
 rel=str(f.relative_to(site));b=backup/rel
 if before is not None:b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,b)
 f.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix='.quality-',dir=f.parent)
 try:
  with os.fdopen(fd,'wb') as out:out.write(raw)
  os.chmod(tmp,0o644);os.replace(tmp,f)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
 manifest.append({'path':rel,'existed':before is not None,'before_sha256':digest(before) if before is not None else None,'after_sha256':digest(raw)});stats['files_changed']+=1
def replaceblock(s,marker,block,position=None):
 start='<!-- '+marker+' start -->';end='<!-- '+marker+' end -->';full=start+block+end
 if start in s:
  lo=s.index(start);hi=s.index(end,lo)+len(end);return s[:lo]+full+s[hi:]
 if position is None:position=s.rfind('</main>')
 if position<0:raise ValueError('main closing tag missing')
 return s[:position]+full+s[position:]
def inject(s):
 if 'sitewide-quality-v55.css' not in s:s=s.replace('</head>','<link rel="stylesheet" href="/sitewide-quality-v55.css"></head>',1)
 return s
shared='<nav class="sitewide-tools" aria-label="자료 확인"><a href="/msds-practical-guides.html">문서 확인 가이드</a><a href="/msds-document-check.html">라벨·MSDS 대조 기록</a><a href="/msds-reviewed-examples.html">원문 대조 사례</a></nav>'
try:
 for i,f in enumerate(files,1):
  s=f.read_text();path='/'+str(f.relative_to(site));key=index[path];company,name=key[:2];d=Doc(s)
  main=next(d.root.walk('main'),None)
  if main is None:raise ValueError('No main in '+path)
  section=next(main.walk('section'),None)
  if section is None:raise ValueError('No product section in '+path)
  pairs={};last=''
  for n in section.walk():
   if n.tag=='dt':last=n.text()
   if n.tag=='dd' and last:pairs[last]=n.text();last=''
  name=pairs.get('제품명',name)
  anchors=[n for n in section.walk('a') if urlsplit(n.attrs.get('href','')).scheme in {'http','https'}]
  if not anchors:raise ValueError('No document destination in '+path)
  primary=anchors[0];url=primary.attrs['href'];u=urlsplit(url)
  if len(key)>2 and key[2]!=url:
   # A key may retain an older URL; the current visible link is used and the identity remains unchanged.
   pass
  info=next((v for k,v in pairs.items() if k in {'자료 정보','문서 형식','문서 정보','형식'}),'')
  button=primary.text();kind='원문 제공 페이지'
  if re.search(r'목록|검색|조회',button):kind='외부 목록·검색 페이지'
  elif re.search(r'zip',button+' '+u.path,re.I):kind='압축파일 안내 경로'
  elif re.search(r'pdf',button+' '+u.path,re.I):kind='PDF로 안내된 경로'
  if kind=='외부 목록·검색 페이지':how='이동한 사이트에서 아래 제품명을 다시 조회하고, 제품·등급이 맞는 문서를 선택하세요. 이 버튼 자체가 제품 PDF를 바로 여는 주소는 아닙니다.'
  elif kind=='압축파일 안내 경로':how='압축파일을 받은 뒤 파일 목록에서 제품명·구성품·언어가 맞는 문서를 선택하세요. 압축파일 하나가 단일 제품 문서를 뜻하지는 않습니다.'
  else:how='원문이 열리면 제품 식별·언어·개정 정보를 실제 라벨과 대조하세요. 링크의 표시 형식이며 이번 적용 시 파일 응답이나 최신성을 전수 확인한 결과는 아닙니다.'
  label=info if info else '이 페이지에 별도 문서 형식·언어 정보가 기재되어 있지 않습니다.'
  ids=[]
  for title,pattern in [('등록 CAS 표기',r'CAS\s*[:：]?\s*(\d{2,7}-\d{2}-\d)'),('등록 SDS 번호',r'SDS\s*번호\s*[:：]?\s*([\w-]+)'),('등록 제품코드',r'제품코드\s*[:：]?\s*([^·]+)')]:
   m=re.search(pattern,info)
   if m:ids.append((title,m[1].strip()))
  for title,value in ids:
   if title=='등록 CAS 표기':
    digits=value.replace('-','');valid=sum((i+1)*int(n) for i,n in enumerate(reversed(digits[:-1])))%10==int(digits[-1])
    if not valid:integrity['cas_check_digit_warning']+=1
  integrity['destination_'+u.scheme]+=1
  if not any(t in info for t in ['국문','영문','언어','한국어','English']):integrity['language_not_stated']+=1
  if re.search(r'보관본|2018',info):integrity['archive_or_2018_label']+=1
  facts=[('등록 업체·브랜드·공급사',company),('대조할 제품명',name)]+ids+[('현재 등록된 자료 표기',label),('이동 경로 유형',kind),('연결 대상 도메인',u.hostname or '')]
  payload={'name':name,'company':company,'url':url};context=quote(json.dumps(payload,ensure_ascii=False,separators=(',',':')),safe='');tool='/msds-document-check.html#document='+context
  block='<section class="product-assistance" aria-labelledby="product-assistance-title"><h2 id="product-assistance-title">이 자료를 선택하기 전에</h2><p>등록 정보와 연결 경로를 정리했습니다. 원문에 대한 기술 검토나 최신성 인증과는 구분하세요.</p><dl>'+''.join('<dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd>' for k,v in facts)+'</dl><p>'+esc(how)+'</p>'
  if u.scheme=='http':block+='<p class="source-caution">이 자료의 등록 주소는 HTTP입니다. 이동 후 HTTPS 전환 및 제공처를 확인하고 개인정보를 입력하지 마세요.</p>'
  if not any(t in info for t in ['국문','영문','언어','한국어','English']):block+='<p class="source-caution">현재 등록 표기만으로 문서 언어를 확정할 수 없습니다. 원문에서 확인하세요.</p>'
  if any(title=='등록 CAS 표기' and sum((i+1)*int(n) for i,n in enumerate(reversed(value.replace('-','')[:-1])))%10!=int(value[-1]) for title,value in ids):
   block+='<p class="source-caution">등록 CAS 표기가 검사숫자 계산과 맞지 않습니다. 다른 번호로 자동 수정하지 않았으니 원문과 공급사 정보를 확인하세요.</p>'
  observation=observations.get(url)
  if observation:
   status=observation.get('status');signature=observation.get('signature');date=observation.get('checked_date','')
   if status in [200,206] and signature=='pdf':message=date+' 익명 접속에서 응답 앞부분의 PDF 표식을 확인했습니다. 원문 전체·제품 일치·최신 개정 여부를 검토했다는 의미는 아닙니다.'
   elif status in [404,410]:message=date+' 익명 접속 점검에서 HTTP '+str(status)+' 응답을 받았습니다. 주소를 삭제하거나 다른 제품으로 바꾸지 않았으며 공급사 또는 원문 제공처 확인이 필요합니다.'
   elif status in [401,403,429]:message=date+' 자동 접속이 제한되어 원문 상태를 확인하지 못했습니다. 깨진 링크로 단정하지 않고 등록 주소를 유지했습니다.'
   elif observation.get('outcome')=='browser_check_required':message=date+' PDF 주소에서 브라우저 확인용 웹페이지 응답을 받았습니다. 이 점검으로는 PDF 파일 자체를 확인하지 못했으며 원문이 깨졌다고 단정하지 않습니다.'
   elif status in [200,206] and signature=='html':message=date+' 익명 접속에서 웹페이지 응답을 받았습니다. PDF 파일 자체의 확인 결과는 아닙니다.'
   elif status is None:message=date+' 이 점검 환경에서는 응답을 확인하지 못했습니다. 이용자 브라우저에서의 접속 불가를 뜻하지 않습니다.'
   else:message=date+' 표본 점검 HTTP '+str(status)+' 응답입니다. 원문 확인 결과는 아닙니다.'
   block+='<details class="request-reference link-observation"><summary>이 주소의 표본 접속 기록</summary><p>'+esc(message)+'</p></details>';integrity['sample_observation_displayed']+=1
  block+='<a class="quality-action" href="'+esc(tool)+'">이 제품 정보로 문서 대조 시작</a><p class="small-note">제품명·업체·원문 주소만 도구에 채웁니다. 용기 라벨 칸은 사용자가 직접 입력합니다. 주소의 # 뒤 내용은 이 도구가 서버로 전송하지 않습니다.</p>'
  ns=neighbours.get(path,[])
  if ns:
   block+='<h3>같은 업체의 다른 등록 자료</h3><p>제품명 정렬상 인접한 자료입니다. 성분·위험성·용도 또는 대체 가능성이 비슷하다는 뜻은 아닙니다. 이름의 다른 부분을 확인할 때 활용하세요.</p><ul class="related-records">'+''.join('<li><a href="'+esc(p)+'">'+esc(n)+'</a></li>' for n,p in ns)+'</ul>'
  else:block+='<p>이 업체의 다른 등록 자료가 없으면 전체 검색에서 공급자명과 제품명을 함께 확인하세요.</p>'
  request='제품 문서 확인 요청\n등록 업체: '+company+'\n제품명: '+name+'\n참고 주소: '+url+'\n확인 요청: 실제 구매 제품에 적용되는 최신 국문 MSDS, 제품코드·등급·구성품 범위와 개정 정보를 확인 부탁드립니다.\n라벨 정보와 다른 점: [직접 작성]'
  block+='<details class="request-reference"><summary>공급사에 확인할 내용 준비하기</summary><p>아래 내용을 복사해 실제 라벨 정보와 함께 공급사에 전달하세요. 이 사이트에서 문의를 자동 전송하지 않습니다.</p><pre>'+esc(request)+'</pre><button type="button" class="request-copy">확인 요청 내용 복사</button><span class="copy-status" role="status" aria-live="polite"></span></details></section>'
  if '<!-- product-assistance-v55 start -->' in s:s=replaceblock(s,'product-assistance-v55',block)
  else:
   # Keep the source card and all verified product-specific summaries ahead of supplementary tools.
   marker=s.find('<section class="ppe-selection')
   if marker<0:marker=s.find('<details class="ppe-selection')
   s=replaceblock(s,'product-assistance-v55',block,marker if marker>=0 else None)
  s=inject(s)
  if '/document-actions-v56.js' not in s:s=s.replace('</head>','<script src="/document-actions-v56.js" defer></script></head>',1)
  write(f,s);stats['products_enriched']+=1
  if i%5000==0:print('SITEWIDE products enriched: '+str(i),flush=True)
 # Every root HTML receives working access to the tools, including the manufacturer directory,
 # paginated company catalogs, guides, information pages and 404. No noindex/canonical changes.
 for f in sorted(site.glob('*.html')):
  s=f.read_text()
  if '</main>' not in s:continue
  if f.name.startswith('manufacturer'):
   content='<section class="catalog-assistance"><h2>자료를 선택할 때 확인할 정보</h2><p>제품 상세페이지에서 등록 제품명·코드·연결 경로와 같은 업체의 다른 자료를 대조할 수 있습니다. 문서 대조 도구는 실제 라벨과 원문을 비교하는 기록용이며 안전 판정 기능은 아닙니다.</p>'+shared+'</section>'
   stats['catalog_pages']+=1
  else:content=shared;stats['other_html_pages']+=1
  if f.name.startswith('manufacturer'):
   rootdoc=Doc(s);h=next(rootdoc.root.walk('h1'),None);title=h.text() if h else ''
   company=next((c for c in sorted(companies,key=len,reverse=True) if title.startswith(c+' ') or title==c),None)
   if company:
    payload=quote(json.dumps({'company':company},ensure_ascii=False,separators=(',',':')),safe='')
    content=content.replace('</section>','<p>'+esc(company)+'의 연결된 상세주소 '+str(len(companies[company]))+'개에서 제품별 등록 정보와 문서 경로를 확인할 수 있습니다. 고유 물질 수나 제조사 전체 제품 수가 아닙니다.</p><a class="quality-action" href="/msds-document-check.html#document='+payload+'">이 업체의 문서 대조 기록 시작</a></section>')
  if f.name=='privacy.html':
   content='<section class="catalog-assistance"><h2>문서 대조 기록 도구</h2><p>문서 대조 도구는 입력값을 서버나 분석 서비스로 전송하거나 브라우저 저장소에 보관하지 않습니다. 제품 상세에서 이동하면 공개 등록 제품명·업체·원문 주소를 주소의 # 뒤 정보로 전달해 문서 칸에 채웁니다. 라벨 정보는 직접 입력하며 새로고침하면 입력값이 사라집니다. 인쇄·PDF 저장은 사용자가 브라우저에서 선택합니다.</p></section>'+content
  if f.name=='about.html':
   content='<section class="catalog-assistance"><h2>등록 정보와 원문 대조를 구분합니다</h2><p>제품별 등록 정보·연결 경로·인접 자료 비교는 문서 선택을 돕는 기능입니다. 원문 대조 요약이 별도로 있는 제품은 확인한 범위와 출처를 표시합니다. 링크·등록 정보가 있다는 사실만으로 제품의 유해성·최신성·국내 규정 적합성을 검증했다고 보지는 않습니다. 비슷한 이름의 다른 제품은 대체 가능한 제품 추천이 아닙니다.</p></section>'+content
  s=replaceblock(s,'sitewide-navigation-v55',content);s=inject(s);write(f,s)
 for f in package.iterdir():
  if f.suffix in {'.css','.js'}:write(site/f.name,f.read_bytes())
 for f in site.glob('*.html'):
  s=f.read_text()
  if '</main>' in s and '/document-actions-v56.js' not in s:s=s.replace('</head>','<script src="/document-actions-v56.js" defer></script></head>',1)
  write(f,s)
 write(site/'site-version.json',json.dumps({'version':'v89','package_date':'2026-11-25','sitewide_quality':True,'source_summaries':410},ensure_ascii=False,indent=2)+'\n')
 report=site/'sitewide-quality-report-v55.json';write(report,json.dumps({k:v for k,v in stats.items() if k!='files_changed'},ensure_ascii=False,indent=2)+'\n')
 write(site/'document-integrity-report-v56.json',json.dumps({'version':'v89','registered_metadata_counts':dict(integrity),'external_sample_urls':len(link_samples),'external_all_urls_checked':False,'full_pdf_review_count':43},ensure_ascii=False,indent=2)+'\n')
 (backup/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print('SITEWIDE QUALITY V89 COMPLETE');print(json.dumps(stats,ensure_ascii=False));print('Backup: '+str(backup))
except BaseException:
 for item in reversed(manifest):
  f=site/item['path']
  if item['existed']:shutil.copy2(backup/item['path'],f)
  else:f.unlink(missing_ok=True)
 print('Failed: all writes from this sitewide step were restored.');raise
