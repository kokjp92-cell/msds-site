MSDS 모아 누적 v86 / 2026-11-25
기존 v85와 모든 MSDS 추가분 포함. 신규 자료 증가는 없음. 홈45,154건 / 자료실카드223개 / 사이트맵45,464URL 유지.
SEO: 정적 HTML에 WebSite(홈), WebPage 또는 CollectionPage, 실제 화면 탐색경로에 대응하는 BreadcrumbList JSON-LD 삽입. 검증되지 않은 리뷰·평점·가격·성분·개정일을 구조화 데이터로 생성하지 않음. 대표 주소를 HTTPS 단일 주소로 통일, 설명 누락시 실제 제목 기반 보완. 기존 본문·제휴 고지·MSDS 링크·주소 및 검색 데이터 유지. 외부 라이브러리·네트워크 요청 추가 없음.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v86-backup
전체 설치 마지막에 SEO 검증 자동 실행. 별도 재검사: python3 seo/verify-seo.py /var/www/msdsmoa
오류0과 SEO V86 COMPLETE 확인. 기존 파일별 백업은 지정한 backup/seo에 보관되며 덮어쓰지 않음.
검증: 로컬 표본1104HTML,1003상세페이지. 제목·설명·대표주소·JSON 문법·탐색경로실재·기존본문/링크/검색assets/사이트맵 보존·문자이스케이프·재실행 불변. 실서버 전체파일은 배포시 검증되며 사전 전수점검 아님.
이 변경이 순위·색인·애드센스 승인을 보장하지 않음. 공급자 공식 원문과 연결 정보의 내용 가치 개선은 계속 필요. 배포 후 Search Console에서 사이트맵 재확인, 상세URL 검사, 페이지색인 보고서 확인 필요. Search Console 등록/제출은 수행하지 않았음.
서버 배포 수행하지 않음.
