v56 점검·수정 누적본 (2026-11-21)
v55 및 이전 추가분 전체 포함. 이것 하나로 적용합니다.

확인한 공개 배포 상태: v53 가이드는 있으나 v55 범위 보고서/최신 사례 페이지는 404였습니다.
이는 사용자가 아직 최신본을 배포하지 않은 상태와 일치하며 서버 적용 실패를 단정하지 않습니다.

수정:
- 전체 products/*.html의 길게 펼쳐진 공통 msds-reading 안내도 접기 방식으로 정리
- 등록 CAS의 검사숫자 불일치를 별도 경고 (원문 번호 자동 수정 아님)
- 모든 상세의 공급사 확인 요청 메모에 복사 버튼, 복사 실패 안내 추가
- 133개 서로 다른 호스트에서 대표 주소 1개씩 익명 GET 표본 점검
  85개 PDF 앞부분, 1개 ZIP 앞부분 확인 / 원문 전체를 읽은 검사 아님
  HTTP 404 2개, 503 3개, 429 1개, 403 1개, 네트워크 미확인 2개
  PDF 대신 HTML 응답인 경우를 PDF 확인으로 간주하지 않음
- HTTP 404 두 주소는 검색/목록/상세 링크에 '점검 시 404' 표시. 기존 링크 삭제/다른 제품으로 대체 안 함
  삼천리 천연가스, 동진페인트 은분페인트: 현재 제공처에서 대체 문서 경로를 확정하지 못함
- 쌍곰: 브라우저 확인용 HTML 응답. 원문이 깨진 것으로 단정하지 않음
- 확인한 주소만 해당 상세에 당시 접속 기록 표시. 같은 도메인 다른 주소로 결과를 일반화하지 않음
- 현재 버전을 확인할 /site-version.json 추가
- /document-integrity-report-v56.json에 서버 전체 등록정보 점검 집계 제공

원문 기반 요약은 36개이며 전체 등록 문서의 유해성 정보를 새로 검토한 것은 아닙니다.
검색 데이터/제품주소/원문 링크/법령/쿠팡 링크/사이트맵 유지.
외부 링크 전수검사 및 애드센스 승인 보장 아님.
외부 확인 원자료: sitewide-quality/external-link-samples.json
CAS 검사숫자 참고: https://www.cas.org/training/documentation/chemical-substances/checkdig

적용:
sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v56-backup
적용 후:
python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
curl -fsSL https://msdsmoa.com/site-version.json

업로드/서버 배포/심사 신청은 수행하지 않았습니다.

추가 검사: 노루 20,134 / KCC 7,026 / 3M 2,952 / 삼화 600 = 30,712개 등록 행의 제품명/주소 누락·완전 중복·URL scheme 확인. 해당 검사에서는 오류 0건. 실제 공개 JSON을 읽어 검사했으며 원문 내용 검증을 뜻하지 않습니다. registration-audit-v56.json 참고.
로컬 상세 609개에서 링크·36개 요약 보존/접기 구성/복사 버튼/최종 재적용 검사 통과. 자동 복사 성공·실패 및 정확한 주소에만 404 표시하는 동작 검사 통과. 브라우저 시각 검사는 수행하지 않았습니다.
