"""Write a complete local inventory of duplicate SEO metadata; do not merge pages."""
import argparse,json,re,sys
from pathlib import Path
from html.parser import HTMLParser
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'locale-seo'))
from locale_fields import Card
class Meta(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.title='';self.desc='';self.cap=False;self.canonical='';self.noindex=False
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='title':self.cap=True
  if t=='meta' and a.get('name')=='description':self.desc=a.get('content','')
  if t=='meta' and a.get('name')=='robots' and 'noindex' in a.get('content',''):self.noindex=True
  if t=='link' and a.get('rel')=='canonical':self.canonical=a.get('href','')
 def handle_endtag(self,t):
  if t=='title':self.cap=False
 def handle_data(self,s):
  if self.cap:self.title+=s
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);a=ap.parse_args();titles={};descs={};errors=[];checked=code_pages=0
for f in sorted(a.site.rglob('*.html')):
 rel=f.relative_to(a.site).as_posix()
 if rel=='404.html' or any(x in ('backup','.git') for x in f.relative_to(a.site).parts):continue
 s=f.read_text();m=Meta();m.feed(s)
 if m.noindex:continue
 c=Card();c.feed(s);fmt=next((c.props.get(k,'') for k in ('자료 정보','문서 형식','현재 등록된 자료 표기') if any(x in c.props.get(k,'') for x in ('제품코드','SDS 번호','문서 ' ,'CAS ','TIG 와이어','솔리드와이어'))),'');code=re.search(r'(제품코드|SDS 번호|문서|CAS)\s+([^·]+)',fmt)
 if not code:
  wire=next((v for v in ('TIG 와이어','솔리드와이어') if v in fmt),None)
  if wire:code=re.search(r'(문서분류) (.*)','문서분류 '+wire)
 row=dict(path='/'+rel,canonical=m.canonical,heading=c.h1,visible_information=c.props)
 if code:
  val=code[2].strip()
  if len(val)<=80 and (code[1]!='문서' or val.isdigit()) and (code[1]!='CAS' or re.fullmatch(r'\d{2,7}-\d{2}-\d',val)):
   code_pages+=1
   if val not in m.title or val not in m.desc:errors.append(rel+': product code absent from metadata')
 titles.setdefault(' '.join(m.title.split()),[]).append(row);descs.setdefault(' '.join(m.desc.split()),[]).append(row);checked+=1
report=dict(html_checked=checked,explicit_identifier_pages=code_pages,title_duplicate_groups=[dict(value=k,pages=v) for k,v in titles.items() if len(v)>1],description_duplicate_groups=[dict(value=k,pages=v) for k,v in descs.items() if len(v)>1],identity_errors=errors)
report['summary']=dict(title_duplicate_groups=len(report['title_duplicate_groups']),description_duplicate_groups=len(report['description_duplicate_groups']),identity_error_count=len(errors))
out=a.site/'seo-duplicate-report-v92.json'
report['summary']['actionable_title_duplicate_groups']=sum(len({p['canonical'] or p['path'] for p in g['pages']})>1 for g in report['title_duplicate_groups'])
report['summary']['canonicalized_title_groups']=report['summary']['title_duplicate_groups']-report['summary']['actionable_title_duplicate_groups']
report['summary']['actionable_description_duplicate_groups']=sum(len({p['canonical'] or p['path'] for p in g['pages']})>1 for g in report['description_duplicate_groups'])
report['summary']['canonicalized_description_groups']=report['summary']['description_duplicate_groups']-report['summary']['actionable_description_duplicate_groups']
text=json.dumps(report,ensure_ascii=False,indent=2)
if not out.exists() or out.read_text()!=text:out.write_text(text)
print('IDENTITY AUDIT V92',json.dumps(dict(html_checked=checked,code_pages=code_pages,**report['summary']),ensure_ascii=False));raise SystemExit(bool(errors))
