from pathlib import Path
from urllib.parse import urlparse, parse_qsl
from html import unescape
import hashlib
import json
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

root = Path(sys.argv[1]).resolve()
data = json.loads(Path(__file__).with_name("lxmma-products.json").read_text())
home = root / "index.html"
directory = root / "manufacturers.html"
source = home.read_text()
match = re.search(r'<script src="(/assets/home-search-[a-f0-9]+\.js)" defer></script>', source)
if not match:
    raise SystemExit("Search bundle not found. No changes.")
bundle = (root / match.group(1).lstrip("/")).read_text()
if "lxmma-documents-v1" in bundle:
    print("LX MMA patch already applied.")
    raise SystemExit(0)
anchor = "const results = document.querySelector('#results');"
if bundle.count(anchor) != 1:
    raise SystemExit("Unexpected search structure. No changes.")

def key(url):
    parsed = urlparse(unescape(url))
    return (parsed.path, tuple(sorted(parse_qsl(parsed.query))))

existing = {key(url) for url in re.findall(r'https?://www\.lxmma\.com/[^"\s<>]+', bundle)}
fresh = [row for row in data if key(row["url"]) not in existing]
labels = {"ko": "국문", "en": "영문"}
records = [
    {"company": "LX MMA", "name": row["name"],
     "keywords": "LX MMA LXMMA LX엠엠에이 " + row["name"] + " " + row["code"],
     "url": row["url"], "verifiedList": row["source"],
     "detail": labels[row["lang"]] + " SDS · 제조사 공식 다운로드",
     "label": labels[row["lang"]] + " SDS 다운로드 ↗",
     "instructions": "문서의 적용 국가·언어와 제품 등급 및 개정일을 확인하세요.",
     "documentLanguage": row["lang"]}
    for row in fresh
]
bundle = bundle.replace(anchor, "// lxmma-documents-v1\nproducts.push(..." + json.dumps(records, ensure_ascii=False) + ");\n" + anchor, 1)
totals = set(re.findall(r'등록 자료 ([\d,]+)건', bundle))
if len(totals) == 1:
    old = totals.pop()
    new = f"{int(old.replace(',', '')) + len(fresh):,}"
    bundle = bundle.replace(old + "건", new + "건")
    source = source.replace(old + "건", new + "건")
bundle_name = "home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
source = source.replace(match.group(1), "/assets/" + bundle_name, 1)
directory_html = directory.read_text()
base = "manufacturer-lxmma"
if base not in directory_html:
    reference = re.search(r'<article class="row">(?:(?!</article>).)*href="/?manufacturer-foosung\.html"(?:(?!</article>).)*</article>', directory_html, re.S)
    if not reference:
        raise SystemExit("Manufacturer list section not found. No changes.")
    card = '<article class="row"><div><h2>LX MMA MSDS</h2><p class="meta">MMA·MAA·BMA 및 수지 제품의 공식 MSDS PDF로 연결합니다.</p><p class="catalog-count">등록 자료 27건</p></div><a class="action" href="manufacturer-lxmma.html">자료 목록 보기 →</a></article>'
    directory_html = directory_html[:reference.end()] + card + directory_html[reference.end():]
filenames = [base + ".html"]
page = Path(__file__).with_name(filenames[0]).read_text()
if not (root / "site-width-960.css").exists():
    page = page.replace('<link rel="stylesheet" href="/site-width-960.css">', '')

outputs = {root / filenames[0]: page}
tree = ET.parse(root / "sitemap.xml")
namespace = "http://www.sitemaps.org/schemas/sitemap/0.9"
ET.register_namespace("", namespace)
known = {node.text for node in tree.findall(f".//{{{namespace}}}loc")}
for name in filenames:
    url = "https://msdsmoa.com/" + name
    if url not in known:
        node = ET.SubElement(tree.getroot(), f"{{{namespace}}}url")
        ET.SubElement(node, f"{{{namespace}}}loc").text = url
if len(tree.getroot()) > 50000:
    raise SystemExit("Sitemap limit exceeded. No changes.")
outputs[root / "assets" / bundle_name] = bundle
outputs[root / "sitemap.xml"] = ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True)
outputs[directory] = directory_html
outputs[home] = source
for path, content in outputs.items():
    temporary = path.with_name(path.name + ".lxmma-tmp")
    try:
        temporary.write_text(content, encoding="utf-8")
        if path.exists():
            shutil.copystat(path, temporary)
        else:
            temporary.chmod(0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
print(f"LX MMA COMPLETE: {len(fresh)} new documents; {len(data) - len(fresh)} existing documents skipped; {len(filenames)} listing pages")
