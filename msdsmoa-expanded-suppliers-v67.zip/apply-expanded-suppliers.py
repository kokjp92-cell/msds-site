"""Apply pending and new supplier updates in order."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
package = Path(__file__).resolve().parent
for supplier in ("samyuk-ka", "tau-htc-kc", "new-suppliers", "catalog-expansion", "verified-pdfs", "additional", "polymer-tdi", "new-companies", "auto-fluids", "fresh-sources", "epoxy-and-supplies", "refrigerants-brazing", "coatings-adhesives", "metals-batteries", "taejin", "jeil-welding", "hanil-industrial", "auto-welding", "coffee-cleaners", "industrial-materials", "bdtech", "chemicals-biochem", "farm-and-adhesives", "sm-industry", "chilman", "soldering", "grouts", "toolcrowd", "cosmo", "tkchem-samyang", "grease-polymer", "universal-oils", "hpnc-istek", "dongsuh-spray", "daemyung-chemical", "fire-suppression", "printing-and-fire", "korea-petroleum", "dongjin-chemical", "bugszone", "cleaning-inorganics", "aekyung-dhc", "lubricants-care", "construction-cosmetics", "hygiene-labs", "aurum-construction", "dongbang-raw-materials", "hanyang-lab-solutions", "cleaning-dispersants", "samwoo-published", "dongsung-lab-reagents", "dana-ink", "domestic-cleaning-archives", "korean-dental-sds", "silicone-cleaning-originals", "polymer-abrasive-adhesives", "calcium-chloride", "industrial-chemicals", "solvents-cleaning-salts", "inorganic-organic-expansion", "minerals-chelating-expansion", "metal-salts-silicates", "alkali-peroxides-organics", "industrial-solvents-expansion", "metalworking-maintenance-materials"):
    script = package / supplier / f"apply-{supplier}.py"
    subprocess.run(
        [sys.executable, str(script), str(args.site), "--backup", str(args.backup / supplier)],
        check=True,
    )

subprocess.run([sys.executable, str(package / "home-layout" / "apply-home-topic-layout.py"), str(args.site), "--backup", str(args.backup / "home-layout")], check=True)

# Apply the document-quality update after all cumulative supplier additions.
subprocess.run([sys.executable, str(package / "content-quality" / "apply-content-quality.py"), str(args.site), "--backup", str(args.backup / "content-quality")], check=True)

subprocess.run([sys.executable, str(package / "sitewide-quality" / "apply-sitewide-quality.py"), str(args.site), "--backup", str(args.backup / "sitewide-quality")], check=True)
