import argparse,json,hashlib,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('site',type=Path);p.add_argument('backup',type=Path);a=p.parse_args();site=a.site.resolve();backup=a.backup.resolve();rows=json.loads((backup/'manifest.json').read_text())
for row in rows:
 f=(site/row['path']).resolve()
 if not f.is_relative_to(site):raise SystemExit('Invalid backup path')
 if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=row['after_sha256']:raise SystemExit('File changed since update; stopped: '+row['path'])
 if row['existed'] and hashlib.sha256((backup/row['path']).read_bytes()).hexdigest()!=row['before_sha256']:raise SystemExit('Backup digest mismatch')
for row in reversed(rows):
 f=site/row['path']
 if row['existed']:shutil.copy2(backup/row['path'],f)
 else:f.unlink()
print('CONTENT QUALITY V53 ROLLBACK COMPLETE')
