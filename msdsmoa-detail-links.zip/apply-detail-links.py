import hashlib
import json
import os
import re
import sys
import tempfile
import xml.etree.ElementTree as ET
from html import escape, unescape
from pathlib import Path

root = Path(sys.argv[1]).resolve()
package = Path(__file__).resolve().parent
company_pages = {'한솔케미칼': 'manufacturer-hansol.html',
                 'LX MMA': 'manufacturer-lxmma.html',
                 '동서석유화학': 'manufacturer-tspc.html'}
rows = json.loads((package / 'new-products.json').read_text())
repairs = json.loads((package / 'existing-links.json').read_text())
template = (package / 'detail-template.html').read_text()
home = root / 'index.html'
sitemap = root / 'sitemap.xml'
home_html = home.read_text()
asset = re.search(r'/assets/detail-index-[a-f0-9]+\.js', home_html)
search_asset = re.search(r'/assets/home-search-[a-f0-9]+\.js', home_html)
if not asset or not search_asset:
    raise SystemExit('Site assets not found.')
prefix = 'window.msdsDetailIndex='
index_source = (root / asset[0].lstrip('/')).read_text().strip()
if not index_source.startswith(prefix):
    raise SystemExit('Unexpected detail index format.')
index = json.loads(index_source[len(prefix):].rstrip(';'))
search = (root / search_asset[0].lstrip('/')).read_text()
original = 'const detailPath = window.msdsDetailIndex?.[detailKey];'
updated = ('const detailPath = window.msdsDetailIndex?.[JSON.stringify([product.company, product.name, product.url])] '
           '|| window.msdsDetailIndex?.[detailKey];')
if updated not in search:
    if search.count(original) != 1:
        raise SystemExit('Unexpected home search detail logic.')
    search = search.replace(original, updated)

ns = 'http://www.sitemaps.org/schemas/sitemap/0.9'
ET.register_namespace('', ns)
tree = ET.parse(sitemap)
known_urls = {node.text for node in tree.findall(f'.//{{{ns}}}loc')}
outputs = {}
linked = {}
reused = 0
skipped = 0
for key, path in repairs.items():
    if not re.fullmatch(r'/(?:products/[a-zA-Z0-9_-]+|foosung-r-123-msds)\.html', path):
        raise SystemExit(f'Unexpected existing detail path: {path}')
    if (root / path.lstrip('/')).is_file():
        index.setdefault(key, path)
        reused += 1
    else:
        skipped += 1

for row in rows:
    company, name = row['company'], row['name']
    if not (root / company_pages[company]).is_file():
        raise SystemExit(f'Catalog missing for {company}')
    key = json.dumps([company, name], ensure_ascii=False, separators=(',', ':'))
    slug = hashlib.sha256(key.encode()).hexdigest()[:24]
    path = index.get(key, f'/products/{slug}.html')
    if not re.fullmatch(r'/products/[a-zA-Z0-9_-]+\.html', path):
        raise SystemExit(f'Unexpected detail path for {name}')
    target = root / path.lstrip('/')
    canonical = 'https://msdsmoa.com' + path
    if not target.is_file():
        fields = {'TITLE': f'{company} {name} MSDS 다운로드',
                  'DESCRIPTION': f'{company} {name} 공식 MSDS와 제조사 자료실을 확인하세요.',
                  'CANONICAL': canonical, 'NAME': name, 'PDF': row['url'], 'COMPANY': company,
                  'CATALOG': '/' + company_pages[company], 'SOURCE': row['source'],
                  'FORMAT': '국문 MSDS · PDF', 'BUTTON': '국문 MSDS PDF 열기 ↗'}
        content = re.sub(r'\{\{([A-Z]+)\}\}', lambda match: escape(fields[match[1]], quote=True), template)
        if (root / 'site-width-960.css').is_file():
            content = content.replace('</head>', '<link rel="stylesheet" href="/site-width-960.css"></head>', 1)
        outputs[target] = content
    index[key] = path
    linked.setdefault(company, {})[name] = path
    if canonical not in known_urls:
        node = ET.SubElement(tree.getroot(), f'{{{ns}}}url')
        ET.SubElement(node, f'{{{ns}}}loc').text = canonical
        known_urls.add(canonical)
if len(tree.getroot()) > 50000:
    raise SystemExit('Sitemap URL limit exceeded.')

for company, links in linked.items():
    catalog = root / company_pages[company]
    page = catalog.read_text()
    seen = set()
    def link_title(match):
        name = unescape(re.sub(r'<[^>]+>', '', match[1])).strip()
        if name not in links:
            return match[0]
        seen.add(name)
        return f'<h3><a href="{links[name]}">{escape(name)}</a></h3>'

    page = re.sub(r'<h3>(.*?)</h3>', link_title, page, flags=re.S)
    if seen != links.keys():
        raise SystemExit(f'Missing catalog entries for {company}: {sorted(links.keys() - seen)}')
    outputs[catalog] = page

index_js = prefix + json.dumps(index, ensure_ascii=False, separators=(',', ':')) + ';\n'
index_path = '/assets/detail-index-' + hashlib.sha256(index_js.encode()).hexdigest()[:12] + '.js'
search_path = '/assets/home-search-' + hashlib.sha256(search.encode()).hexdigest()[:12] + '.js'
outputs[root / index_path.lstrip('/')] = index_js
outputs[root / search_path.lstrip('/')] = search
outputs[sitemap] = ET.tostring(tree.getroot(), encoding='unicode', xml_declaration=True)
outputs[home] = home_html.replace(asset[0], index_path, 1).replace(search_asset[0], search_path, 1)
for path, content in outputs.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as out:
        out.write(content)
    temporary = Path(out.name)
    try:
        temporary.chmod(path.stat().st_mode & 0o777 if path.exists() else 0o644)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
print(f'DETAIL LINKS COMPLETE: {sum(map(len, linked.values()))} catalog links, {reused} existing detail paths, {skipped} unavailable paths skipped')
