from html.parser import HTMLParser
class Card(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.props={};self.label='';self.cap=None;self.buf='';self.h1='';self.inh=False
 def handle_starttag(self,t,a):
  if t in ('dt','dd'):self.cap=t;self.buf=''
  if t=='h1':self.inh=True
 def handle_data(self,s):
  if self.cap:self.buf+=s
  if self.inh:self.h1+=s
 def handle_endtag(self,t):
  if t==self.cap:
   if t=='dt':self.label=' '.join(self.buf.split())
   else:self.props.setdefault(self.label,' '.join(self.buf.split()))
   self.cap=None
  if t=='h1':self.inh=False
