import argparse,re,json,sys,hashlib,shutil
from pathlib import Path
from html import escape,unescape
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'locale-seo'))
from locale_fields import Card
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();profiles=json.loads((Path(__file__).parent/'verified-document-identities.json').read_text());by={r['url']:r for r in profiles};changed=0

def write(f,out):
 global changed
 if f.read_text()==out:return
 b=a.backup/f.relative_to(a.site);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():shutil.copy2(f,b)
 f.write_text(out);changed+=1
for f in (a.site/'products').glob('*.html'):
 s=f.read_text();section=re.search(r'<section\b[^>]*>.*?</section>',s,re.S)
 if not section:continue
 urls=[unescape(x[1]) for x in re.findall(r'href=([\"\x27])(.*?)\1',section[0],re.S)];r=next((by[u] for u in urls if u in by),None)
 if not r:continue
 c=Card();c.feed(s);parts=[]
 if re.sub(r'\s+','',c.props.get('제품명','')).casefold()!=re.sub(r'\s+','',r['document_name']).casefold():parts.append('원문명 '+r['document_name'])
 rows=[('원문 제품명',r['document_name'])]
 if r.get('document_number'):rows.append((r.get('number_label','문서번호'),r['document_number']));parts.append(r.get('number_label','문서번호')+' '+r['document_number'])
 if r.get('revision'):rows.append(('원문 개정일 표기',r['revision']));parts.append('개정 '+r['revision'])
 if r.get('revision_number'):rows.append(('원문 개정횟수',r['revision_number']));parts.append('개정 '+r['revision_number']+'회')
 if r.get('issue_date'):rows.append(('원문 최초발행일',r['issue_date']))
 if r.get('issue_date') and not r.get('revision'):parts.append('발행 '+r['issue_date'])
 if r.get('document_version'):rows.append(('원문 버전',r['document_version']));parts.append('버전 '+r['document_version'])
 codeinfo=next((c.props.get(k,'') for k in ('자료 정보','문서 형식','현재 등록된 자료 표기') if '제품코드' in c.props.get(k,'')),'');productcode=re.search(r'제품코드\s+([^·]+)',codeinfo)
 if productcode and productcode[1].strip() not in c.h1:parts.append('제품코드 '+productcode[1].strip())
 fmt=next((v for v in c.props.values() if '언어' in v and '국가' in v),'');m=re.search(r'언어\s+([^·]+)',fmt);n=re.search(r'국가\s+([^·]+)',fmt)
 if m:parts.append(m[1].strip())
 if n:parts.append(n[1].strip())
 rows.append(('원문 식별정보 확인일',r['checked']));block='<!-- verified-identity-v91 start --><div class="source-caution" id="verified-identity-v91"><h3>원문 문서 식별정보</h3><dl>'+''.join('<dt>'+escape(k)+'</dt><dd>'+escape(v)+'</dd>' for k,v in rows)+'</dl>'
 if re.sub(r'\s+','',c.props.get('제품명','')).casefold()!=re.sub(r'\s+','',r['document_name']).casefold():block+='<p>등록된 제품명과 원문 표기가 다릅니다. 사용 중인 제품 라벨과 원문 제품명을 대조하세요.</p>'
 block+='</div><!-- verified-identity-v91 end -->';out=re.sub(r'<!-- verified-identity-v91 start -->.*?<!-- verified-identity-v91 end -->','',s,flags=re.S);pos=out.find('</dl>',out.find('<section'))
 if pos<0:raise ValueError('Product information list missing: '+str(f))
 out=out[:pos+5]+block+out[pos+5:];title=c.h1+(' ['+' · '.join(parts)+']' if parts else '')+' | MSDS 모아';desc=c.h1+'. 원문 제품명 '+r['document_name']+'. '+'. '.join(parts)+'. 실제 제품 라벨과 공급자를 대조하세요.'
 out=re.sub(r'<title>.*?</title>','<title>'+escape(title)+'</title>',out,count=1,flags=re.S);out=re.sub(r'<meta\b(?=[^>]*name=[\"\x27]description[\"\x27])[^>]*>','<meta name="description" content="'+escape(desc,quote=True)+'">',out,count=1,flags=re.I);write(f,out)
home=a.site/'index.html';h=home.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];s=(a.site/old[1:]).read_text();public={r['url']:{'name':r['document_name'],'number':r.get('document_number',''),'revision':r.get('revision','')} for r in profiles}
if '// verified-search-identities-v91' not in s:
 marker='const searchTextCache = new WeakMap();';assert marker in s;s=s.replace(marker,'const verifiedIdentitiesV91 = '+json.dumps(public,ensure_ascii=False)+';\n'+marker)
 source='${product.keywords || \'\'} ${product.detail || \'\'}';target=source+' ${verifiedIdentitiesV91[product.url]?.name || \'\'} ${verifiedIdentitiesV91[product.url]?.number || \'\'}';assert source in s;s=s.replace(source,target)
 marker='details.append(badge);';assert marker in s;s=s.replace(marker,marker+"\n  if (verifiedIdentitiesV91[product.url]) details.append(element('p', '원문 제품명: '+verifiedIdentitiesV91[product.url].name+' · '+(verifiedIdentitiesV91[product.url].number || ''), 'note'));")
 s+='\n// verified-search-identities-v91\n';new='/assets/home-search-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js';(a.site/new[1:]).write_text(s);write(home,h.replace(old,new))
# Keep an existing search bundle synchronized with the reviewed identity manifest.
h=home.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];bundle=(a.site/old[1:]).read_text();updated=re.sub(r'^const verifiedIdentitiesV91 = .*;$','const verifiedIdentitiesV91 = '+json.dumps(public,ensure_ascii=False)+';',bundle,flags=re.M)
if updated!=bundle:
 new='/assets/home-search-'+hashlib.sha256(updated.encode()).hexdigest()[:12]+'.js';(a.site/new[1:]).write_text(updated);write(home,h.replace(old,new))
print('VERIFIED IDENTITIES V91 COMPLETE',changed,'profiles',len(profiles))
