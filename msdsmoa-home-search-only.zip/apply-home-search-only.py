"""Show home results only when a visitor searches."""
import argparse
import hashlib
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
if 'id="msds-search-results"' in html:
    print("Home search-only patch already applied.")
    raise SystemExit(0)

search = re.search(r'(<meta id="msds-search-bundle" content="(/assets/home-search-[a-f0-9]+\.js)">)<script>.*?</script>', html, re.S)
section = re.search(r'<section\b[^>]*\bid="results"[^>]*>.*?</section>', html, re.S)
if not search or not section:
    raise SystemExit("Expected the home startup patch. No changes made.")

bundle = (args.site / search[2][1:]).read_text(encoding="utf-8")
bundle = replace_once(bundle, "  const normalizedQuery = normalizeQuery(query.value);", """  const normalizedQuery = normalizeQuery(query.value);
  const panel = document.getElementById('msds-search-results');
  panel.hidden = !normalizedQuery;
  if (!normalizedQuery) {
    results.replaceChildren();
    heading.textContent = heading.dataset.registered;
    document.querySelector('#search-readiness').textContent = '';
    return;
  }""")
bundle = replace_once(bundle, "'자료 목록 준비 중 · 현재 불러온 자료부터 검색합니다. 완료되면 결과가 자동으로 갱신됩니다.'",
                      "'자료를 불러오는 중…'")
bundle = replace_once(bundle, "검색 결과 ${matches.length.toLocaleString('ko-KR')}건${catalogLoadState.pending ? ' · 자료 준비 중' : ''}",
                      "검색 결과 ${matches.length.toLocaleString('ko-KR')}건")
asset = "/assets/home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"

intro = re.search(r'<p class="note">제조사를 눌러 자료를 펼치세요\..*?</p>', html, re.S)
statuses = re.findall(r'<p id="(?:catalog-status|kcc-catalog-status|three-m-catalog-status|samhwa-catalog-status)"[^>]*>[^<]*</p>', html)
heading = re.search(r'<h2 id="heading" aria-live="polite">(등록 자료 [\d,]+건)</h2>', html)
status = re.search(r'(<p id="search-readiness"[^>]*>)[^<]*</p>', html)
if not intro or len(statuses) != 4 or not heading or not status:
    raise SystemExit("Expected home search labels. No changes made.")

html = replace_once(html, heading[0], f'<h2 id="heading" aria-live="polite" data-registered="{heading[1]}">{heading[1]}</h2>')
html = replace_once(html, status[0], status[1] + '</p>')
html = replace_once(html, intro[0], '')
for item in statuses:
    html = replace_once(html, item, '')
errors = ''.join(item.split('>', 1)[0] + ' hidden></p>' for item in statuses)
fallback = re.search(r'<div class="seo-maker-links">.*?</div>', section[0], re.S)
panel = '<div id="msds-search-results" hidden>' + errors
panel += '<section tabindex="0" id="results" aria-labelledby="heading" aria-live="polite"></section></div>'
if fallback:
    panel += '<noscript>' + fallback[0] + '</noscript>'
html = replace_once(html, section[0], panel)
html = replace_once(html, '</head>', '<style>#msds-search-results[hidden],#search-readiness:empty{display:none}</style></head>')
bootstrap = Path(__file__).with_name("startup.js").read_text(encoding="utf-8")
html = replace_once(html, search[0], f'<meta id="msds-search-bundle" content="{asset}"><script>{bootstrap}</script>')

args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
publish(args.site / asset[1:], bundle, 0o644)
publish(home, html, home.stat().st_mode)
print(f"HOME SEARCH ONLY COMPLETE\nBackup: {args.backup / home.name}")
