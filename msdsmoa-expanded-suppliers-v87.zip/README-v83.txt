MSDS 모아 v83 / 2026-11-25
기존 v82 및 모든 이전분 포함 누적 패키지. 신규 업체 인터플론 한국용 국문 SDS 6건: Grease OG, Grease LS2, Food Grease 000, Food Grease 1, Lube TF (Aerosol), Lube EPR.
공식 정적 자료 서버의 전체 PDF 다운로드·제품명·공급업체·개정일·해시 확인. 원본 PDF 재배포하지 않고 공식 링크 제공. 전체 성분/유해성 기술 심사 아님. 국내판 표시와 국문을 확인했으나 납품업체 및 실제 제품 라벨과 대조 필요. EPR 원문 개정일 2026-06-04는 검색 캐시와 달라 실제 PDF 날짜 적용. TF는 에어로졸형으로 구분.
배포 후 홈45,139건 / 공급사222개 / 사이트맵45,448 URL / 제품 식별 설명395건 예상. 검색·상세·자료실·사이트맵·법령/보호구·제휴 고지 연결 및 기존 주소/데이터 보존, 재실행 검사 통과. 로컬988개 부분 상세파일 검사, 실서버 전체 검사는 별도.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v83-backup
배포 후 검사: python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
서버 배포 수행하지 않음. chemical-additions-v83.csv / verified-sources-v83.json 참고.
