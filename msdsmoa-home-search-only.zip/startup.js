(() => {
  const form = document.getElementById('search');
  const input = document.getElementById('query');
  const status = document.getElementById('search-readiness');
  const config = document.getElementById('msds-search-bundle');
  const urlQuery = () => new URLSearchParams(location.search).get('q') || '';
  let loading = false;
  let ready = false;
  let composing = false;

  function start() {
    if (ready || loading || !input.value.trim()) return;
    loading = true;
    status.textContent = '자료를 불러오는 중…';
    const script = document.createElement('script');
    script.src = config.content;
    script.onload = () => {
      ready = true;
      input.dispatchEvent(new Event('input'));
    };
    script.onerror = () => {
      loading = false;
      script.remove();
      if (input.value.trim()) status.textContent = '검색 자료를 불러오지 못했습니다. 검색 버튼을 다시 누르거나 제조사별 자료실을 이용하세요.';
    };
    document.head.append(script);
  }

  input.value = urlQuery();
  input.addEventListener('compositionstart', () => { composing = true; });
  input.addEventListener('compositionend', () => {
    composing = false;
    if (input.value.trim()) start();
  });
  input.addEventListener('input', () => {
    if (composing || ready) return;
    if (input.value.trim()) {
      if (loading) status.textContent = '자료를 불러오는 중…';
      start();
    } else {
      status.textContent = '';
    }
  });
  form.addEventListener('submit', event => {
    if (ready) return;
    event.preventDefault();
    const url = new URL(location.href);
    if (input.value.trim()) url.searchParams.set('q', input.value.trim());
    else url.searchParams.delete('q');
    if (url.href !== location.href) history.pushState(null, '', url.href);
    start();
  });
  window.addEventListener('popstate', () => {
    if (ready) return;
    input.value = urlQuery();
    input.dispatchEvent(new Event('input'));
  });
  if (input.value.trim()) start();
})();
