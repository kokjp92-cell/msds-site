"""Differentiate source documents using product codes already visible on each page."""
import argparse,re,shutil,sys,json
from pathlib import Path
from html import escape
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'locale-seo'))
from locale_fields import Card
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();checked=changed=0
for f in sorted((a.site/'products').glob('*.html')):
 src=f.read_text();c=Card();c.feed(src);fmt=next((c.props.get(k,'') for k in ('자료 정보','문서 형식','현재 등록된 자료 표기') if any(x in c.props.get(k,'') for x in ('제품코드','SDS 번호','문서 ' ,'CAS ','TIG 와이어','솔리드와이어'))),'');code=re.search(r'(제품코드|SDS 번호|문서|CAS)\s+([^·]+)',fmt)
 if not code:
  wire=next((v for v in ('TIG 와이어','솔리드와이어') if v in fmt),None)
  if wire:code=re.search(r'(문서분류) (.*)','문서분류 '+wire)
 if not code:continue
 kind,code=code[1],code[2].strip()
 label={'CAS':'등록 CAS','문서':'자료실 문서번호','문서분류':'자료 분류'}.get(kind,kind)
 if not code or len(code)>80 or (kind=='문서' and not code.isdigit()) or (kind=='CAS' and not re.fullmatch(r'\d{2,7}-\d{2}-\d',code)):continue
 checked+=1;parts=[]
 if code not in c.h1:parts.append(label+' '+code)
 lang=re.search(r'언어\s+([^·]+)',fmt);country=re.search(r'국가\s+([^·]+)',fmt)
 if lang:parts.append(lang[1].strip())
 if country:parts.append(country[1].strip())
 title=c.h1+(' ['+' · '.join(parts)+']' if parts else '')+' | MSDS 모아'
 desc=c.h1+'. '+label+' '+code+'. '+(('문서 언어 '+lang[1].strip()+'. ') if lang else '')+(('적용 국가 '+country[1].strip()+'. ') if country else '')+'원문에서 제품명·공급자·개정일을 납품 라벨과 대조하세요.'
 out=re.sub(r'<title>.*?</title>','<title>'+escape(title)+'</title>',src,count=1,flags=re.S|re.I);out=re.sub(r'<meta\b(?=[^>]*name=[\"\x27]description[\"\x27])[^>]*>','<meta name="description" content="'+escape(desc,quote=True)+'">',out,count=1,flags=re.I)
 if out!=src:
  b=a.backup/f.relative_to(a.site);b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():shutil.copy2(f,b)
  f.write_text(out);changed+=1
print('IDENTITY SEO V91 COMPLETE',json.dumps(dict(explicit_identifier_pages=checked,changed=changed)))
