import argparse,hashlib,re,shutil
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();home=a.site/'index.html';h=home.read_text();match=re.search(r'id="msds-search-bundle" content="([^"]+)"',h);assert match,'Search bundle not found';old=match[1];f=a.site/old.lstrip('/');s=f.read_text()
normal='''function normalizeSearchText(value) {
  return String(value ?? '').normalize('NFKC').toLowerCase().replace(/[‐‑‒–—−]/g, '-').replace(/\\s+/g, ' ').trim();
}
function compactSearchText(value) {
  return normalizeSearchText(value).replace(/[\\s_-]+/g, '');
}
function normalizeQuery(value) {
  return normalizeSearchText(value).replace(/(?:3m|쓰리엠)\\s+(\\d+[a-z]*)(?=\\s|$)/g, '3m$1');
}'''
cache='''const searchTextCache = new WeakMap();
const compactSearchTextCache = new WeakMap();
function searchText(product) {
  if (!searchTextCache.has(product)) searchTextCache.set(product, normalizeSearchText(`${product.name} ${product.company} ${product.keywords || ''} ${product.detail || ''}`));
  return searchTextCache.get(product);
}
function matchesSearchTerm(product, term) {
  if (searchText(product).includes(term)) return true;
  if (!compactSearchTextCache.has(product)) compactSearchTextCache.set(product, compactSearchText(searchText(product)));
  const needle = compactSearchText(term);
  return !!needle && compactSearchTextCache.get(product).includes(needle);
}
'''
if '// search-v87' not in s:
 start=s.index('function normalizeQuery(');end=s.index('function formatCode(',start);s=s[:start]+normal+'\n'+s[end:]
 start=s.index('const searchTextCache =');end=s.index('let searchTimer;',start);s=s[:start]+cache+s[end:]
 oldmatch='terms.every(term => searchText(product).includes(term))';assert oldmatch in s;s=s.replace(oldmatch,'terms.every(term => matchesSearchTerm(product, term))')
 oldcompact="const compact = value => value.toLowerCase().replace(/[\\s_-]+/g, '');";assert oldcompact in s;s=s.replace(oldcompact,'const compact = compactSearchText;')
 s=s.replace("const words = product.name.toLowerCase();","const words = normalizeSearchText(product.name);")
 s=s.replace("product-code matches over incidental", "product-code matches over incidental")
 s+='\n// search-v87\n'
 new='/assets/home-search-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js';(a.site/new.lstrip('/')).write_text(s);a.backup.mkdir(parents=True,exist_ok=True)
 if not (a.backup/'index.html').exists():shutil.copy2(home,a.backup/'index.html')
 home.write_text(h.replace(old,new));print('SEARCH V87 COMPLETE',new)
else:print('SEARCH V87 ALREADY APPLIED')
