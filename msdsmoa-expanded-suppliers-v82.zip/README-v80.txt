MSDS 모아 v80 / 2026-11-25
이전 v79 및 모든 이전 추가분을 포함하는 누적 ZIP입니다. 산업용 그리스8건, 윤활유1건을 추가합니다.
SJ 자동구리스 공개 자료실: AeroShell Grease22, MOBILUX EP2, BC-OHD NO.1,2,3(공통1문서), ZENITH EP00/EP1/EP2/RHD2/XTR PLUS.
Klüber Summit 제조사 공식: SH-46 T 국문 SDS, 품목340155, MSDS AA00457-0000000440, 국내 연락처 크리버코리아.
모든9건의 원문 제품명·제조자/공급자·개정일·문서 식별정보 및 전체 다운로드 해시를 확인했습니다. SJ 자료는 공급사 공개 보관본이며 SJ가 제조사라고 표기하지 않습니다. 원문 공급자는 MOBILUX의 모빌코리아, BECO의 백호테크원, ZENITH의 이에이치에스테크루브, AeroShell의 글로벌 에이치비로 구분해 자체 식별 메모에 기록했습니다. SH-46 T의 외국 제조자와 국내 연락처 역할도 구분합니다.
AeroShell22는2021-11-08, BECO OHD는2020-02-17 보관본으로 최신본으로 보장하지 않습니다. 나머지 날짜는 신규CSV 및 확인근거JSON 참고. BC-OHD3등급은 공통 문서1건으로 집계합니다. 기존 브랜드와 중복 확인이 필요한 Kixx EP1과 Super Lube는 신규로 넣지 않았습니다.
원본PDF는 재배포하지 않습니다. 원문 전체 유해성·성분·현행 법적 적합성 기술심사나 특정 장비 사용 추천은 수행하지 않았습니다. 실제 납품 제품과 공급자 최신문서를 대조하세요.
배포 후 홈45,119건 / 공급사 카드220개 / 신규SJ 자동구리스8건, 크리버코리아1건 / 기존 한국쉘석유24건 유지 / 사이트맵45,426 URL / 제품 식별 설명375건 예상.
로컬 일부968개 상세파일과 전체45,113개 상세주소 매핑에서 검색·자료실·상세·사이트맵·법령/보호구·최상단 제휴 고지·기존 주소와 링크 보존·재실행 불변 검사 수행. 실서버 전체 파일 검사는 수행하지 않았습니다.
적용: sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v80-backup
배포 후 검사: python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
신규목록 chemical-additions-v80.csv / 확인근거 verified-sources-v80.json. 깃허브 업로드와 서버 배포는 별개이며 서버 배포는 수행하지 않았습니다.
