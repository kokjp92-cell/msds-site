"""Tidy the home search layout."""
import argparse
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
if 'id="home-search-guide"' in html:
    print("Home layout patch already applied.")
    raise SystemExit(0)

heading = re.search(
    r'(<div class="results-heading"><h2 id="heading"[^>]*>)(등록 자료 [\d,]+건)(</h2></div>)'
    r'(<div id="msds-search-results" hidden>)', html
)
form = re.search(r'<form id="search">.*?</form>', html, re.S)
guide = re.search(
    r'<section aria-labelledby="guide" class="info-section"><h2 id="guide">사이트 사용 방법</h2>'
    r'(.*?)</section>', html, re.S
)
if not heading or not form or not guide:
    raise SystemExit("Expected the search-only home layout. No changes made.")

html = replace_once(html, heading[0], heading[4] + heading[1] + heading[3])
html = replace_once(html, form[0], form[0] + f'<p class="hero-search-count">{heading[2]}</p>')
html = replace_once(
    html, guide[0],
    '<details id="home-search-guide"><summary id="guide">검색 도움말</summary>'
    f'<div class="home-guide-body">{guide[1]}</div></details>',
)
styles = """<style>
header .hero .hero-search-count{margin:10px 0 0;color:#d5e4e8;font-size:.875rem}
#home-search-guide{margin:20px 0 0;border:1px solid #d3e1e5;border-radius:10px;background:#fff}
#home-search-guide>summary{padding:12px 16px;cursor:pointer;font-weight:650}
#home-search-guide .home-guide-body{padding:0 16px 16px}
#home-search-guide .home-guide-body>p{margin-top:0}
</style>"""
html = replace_once(html, "</head>", styles + "</head>")
args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
publish(home, html, home.stat().st_mode)
print(f"HOME LAYOUT COMPLETE\nBackup: {args.backup / home.name}")
