#!/usr/bin/env python3
"""Add reviewed summaries and practical guides without changing product URLs or search data."""
import argparse,html,json,re,shutil,tempfile,hashlib,os,sys
from pathlib import Path
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
P=argparse.ArgumentParser();P.add_argument('site',type=Path);P.add_argument('--backup',type=Path,required=True);a=P.parse_args();site=a.site.resolve();package=Path(__file__).resolve().parent
if not (site/'index.html').is_file():raise SystemExit('Site index.html not found; no files changed.')
profiles=json.loads((package/'reviewed-products.json').read_text())
class Sections(HTMLParser):
 def __init__(self,s):
  super().__init__(convert_charrefs=False);self.s=s;self.offsets=[0];self.items=[];self.stack=[]
  for m in re.finditer('\n',s):self.offsets.append(m.end())
  self.feed(s)
 def start(self):l,c=self.getpos();return self.offsets[l-1]+c
 def handle_starttag(self,t,attrs):
  if t=='section':self.stack.append((self.start(),dict(attrs)))
 def handle_endtag(self,t):
  if t=='section' and self.stack:
   start,attrs=self.stack.pop();end=self.s.find('>',self.start())+1
   self.items.append((start,end,attrs))
def digest(b):return hashlib.sha256(b).hexdigest()
def fold(s):
 spans=Sections(s).items
 for start,end,attrs in sorted(spans,reverse=True):
  cls=attrs.get('class','').split()
  if not set(cls)&{'ppe-selection','ppe-shopping','msds-law','msds-reading'}:continue
  block=s[start:end];head=re.search(r'<h2\b([^>]*)>(.*?)</h2>',block,re.S|re.I)
  if not head:continue
  inner=block[block.find('>')+1:block.rfind('</section>')]
  summary='<summary'+head[1]+'>'+head[2]+'</summary>'
  inner=inner.replace(head[0],summary,1)
  # These are shared reference sections; product-specific reviewed material stays expanded.
  new='<details class="'+html.escape(attrs.get('class',''),quote=True)+' quality-reference">'+inner+'</details>'
  s=s[:start]+new+s[end:]
 return s
def stripads(s):
 def remove(m):
  b=m[0]
  if re.search(r'<script\b[^>]*\bsrc\s*=\s*[\"\'][^\"\']*(?:pagead2\.googlesyndication\.com|googlesyndication\.com/pagead)',b,re.I):return ''
  if re.fullmatch(r'<script\b[^>]*>\s*\(?\s*(?:window\.)?adsbygoogle\s*=.*?\.push\(\s*\{\s*\}\s*\)\s*;?\s*</script>',b,re.S|re.I):return ''
  return b
 s=re.sub(r'<script\b[^>]*>.*?</script>',remove,s,flags=re.S|re.I)
 s=re.sub(r'<ins\b[^>]*class=[\"\'][^\"\']*\badsbygoogle\b[^\"\']*[\"\'][^>]*>.*?</ins>','',s,flags=re.S|re.I)
 return s
# All visitor-facing labels are Korean.
nav='<nav class="quality-nav" aria-label="문서 확인 도움말"><a href="/msds-practical-guides.html">문서 확인 가이드</a><a href="/msds-document-check.html">라벨·문서 대조 도구</a></nav>'
css='<link rel="stylesheet" href="/content-quality-v53.css">'
changed=[];matched=set();counts={'products_scanned':0,'reviewed_summaries':0,'summaries_added':0,'ads_pages_cleaned':0,'files_changed':0}
a.backup.mkdir(parents=True,exist_ok=True);backup=Path(tempfile.mkdtemp(prefix='content-quality-',dir=a.backup.resolve()));manifest=[]
def write(path,data):
 raw=data.encode('utf-8') if isinstance(data,str) else data
 before=path.read_bytes() if path.exists() else None
 if before==raw:return
 rel=str(path.relative_to(site));dest=backup/rel
 if before is not None:dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
 path.parent.mkdir(parents=True,exist_ok=True)
 fd,tmp=tempfile.mkstemp(prefix='.quality-',dir=path.parent)
 try:
  with os.fdopen(fd,'wb') as f:f.write(raw)
  os.chmod(tmp,0o644);os.replace(tmp,path)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
 manifest.append({'path':rel,'existed':before is not None,'before_sha256':digest(before) if before is not None else None,'after_sha256':digest(raw)})
 counts['files_changed']+=1
try:
 products=list((site/'products').glob('*.html'))
 for f in products:
  s=f.read_text();before=s;counts['products_scanned']+=1
  if counts['products_scanned']%5000==0:print('Products checked: '+str(counts['products_scanned']),flush=True)
  plain=html.unescape(s)
  for i,d in enumerate(profiles):
   if d['url'] not in plain:continue
   matched.add(i)
   if 'id="reviewed-product-v53"' not in s:
    fields=[('원문 제품정보·용도',d['use']),('원문 위험정보 확인',d['hazard']),('취급·보관 확인',d['handling']),('원문 노출 관리·보호구',d['ppe']),('비슷한 제품과 구분',d['distinction'])]
    block='<section id="reviewed-product-v53" class="reviewed-product"><h2>이 제품 원문에서 확인한 내용</h2><p class="review-meta">MSDS 모아 원문 대조 · '+html.escape(d['checked'])+' · '+html.escape(d['format'])+'</p><dl>'+''.join('<dt>'+html.escape(k)+'</dt><dd>'+html.escape(v)+'</dd>' for k,v in fields)+'</dl><p>제품 선택을 돕는 제한된 요약입니다. 원문 전체·최신 공급사 문서·실제 작업 조건을 함께 확인하세요. 원문의 오기나 규정 적합성을 인증하지 않습니다.</p><p><a href="'+html.escape(d['url'],quote=True)+'" target="_blank" rel="noopener noreferrer">대조한 원문 PDF</a> · <a href="/msds-version-language.html">개정일·언어 확인 방법</a></p></section>'
    first=next((x for x in sorted(Sections(s).items) if 'ppe-selection' in x[2].get('class','').split()),None)
    at=first[0] if first else s.rfind('</main>')
    if at<0:raise ValueError('Product main section missing: '+str(f))
    s=s[:at]+block+s[at:]
    counts['summaries_added']+=1
   counts['reviewed_summaries']+=1
  s=fold(s)
  if 'class="quality-nav"' not in s:s=s.replace('</main>',nav+'</main>',1)
  if 'content-quality-v53.css' not in s:s=s.replace('</head>',css+'</head>',1)
  if 'link.coupang.com' in s and 'class="affiliate-disclosure"' not in s:
   disclosure='<aside class="affiliate-disclosure">이 게시물은 쿠팡 파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다.</aside>'
   s=re.sub(r'(<main\b[^>]*>)',lambda m:m[1]+disclosure,s,count=1)
  s=stripads(s)
  if 'googlesyndication.com' in before and before!=s and 'googlesyndication.com' not in s:counts['ads_pages_cleaned']+=1
  write(f,s)
 if len(matched)!=len(profiles):raise ValueError('Reviewed products missing from this site: '+str([d['name'] for i,d in enumerate(profiles) if i not in matched]))
 for f in list(site.glob('manufacturer*.html'))+[site/'404.html',site/'feedback.html']:
  if not f.exists():continue
  s=f.read_text();before=s;s=stripads(s)
  if f.name.startswith('manufacturer') and 'class="quality-nav"' not in s:s=s.replace('</main>',nav+'</main>',1)
  if 'class="quality-nav"' in s and 'content-quality-v53.css' not in s:s=s.replace('</head>',css+'</head>',1)
  if s!=before and 'googlesyndication.com' in before and 'googlesyndication.com' not in s:counts['ads_pages_cleaned']+=1
  write(f,s)
 for f in package.iterdir():
  if f.suffix=='.html':
   s=f.read_text()
   if 'rel="canonical"' not in s:s=s.replace('</head>','<link rel="canonical" href="https://msdsmoa.com/'+f.name+'"></head>')
   write(site/f.name,s)
  elif f.suffix in {'.css','.js'}:write(site/f.name,f.read_bytes())
 home=site/'index.html';s=home.read_text()
 if 'id="practical-guides-v53"' not in s:
  block='<section id="practical-guides-v53" class="quality-home"><h2>찾은 문서가 내 제품에 맞는지 확인하세요</h2><p>제품명·등급·구성품과 원문의 언어·개정 정보를 대조하는 방법을 실제 등록 사례로 정리했습니다.</p>'+nav+'<p><a href="/msds-reviewed-examples.html">원문 대조 제품 36건과 선택 사례 보기</a></p><ul><li><a href="/msds-label-check.html">라벨·제품코드 확인</a></li><li><a href="/msds-components.html">주제·경화제 구분</a></li><li><a href="/msds-version-language.html">개정일·언어·국가 구분</a></li><li><a href="/msds-reading-order.html">원문에서 필요한 항목 찾기</a></li></ul></section>'
  s=s.replace('</main>',block+'</main>',1)
 if 'content-quality-v53.css' not in s:s=s.replace('</head>',css+'</head>',1)
 if '/msds-reviewed-examples.html' not in s:
  s=s.replace('</main>','<p class="quality-nav"><a href="/msds-reviewed-examples.html">원문 대조 제품 36건과 선택 사례</a></p></main>',1)
 # Keep the homepage AdSense connection code; search data/scripts and verification identifiers are preserved.
 write(home,s)
 sitemap=site/'sitemap.xml'
 if sitemap.exists():
  tree=ET.fromstring(sitemap.read_bytes());ns='http://www.sitemaps.org/schemas/sitemap/0.9';ET.register_namespace('',ns);existing={n.text for n in tree.findall('{'+ns+'}url/{'+ns+'}loc')}
  for f in sorted(package.glob('*.html')):
   url='https://msdsmoa.com/'+f.name
   if url not in existing:ET.SubElement(ET.SubElement(tree,'{'+ns+'}url'),'{'+ns+'}loc').text=url
  if len(tree)>50000:raise ValueError('Sitemap exceeds 50000 URLs; split before applying.')
  write(sitemap,ET.tostring(tree,encoding='utf-8',xml_declaration=True))
 (backup/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));(backup/'result.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2))
 print('CONTENT QUALITY V54 COMPLETE');print(json.dumps(counts,ensure_ascii=False));print('Backup: '+str(backup))
except BaseException:
 for entry in reversed(manifest):
  f=site/entry['path']
  if entry['existed']:shutil.copy2(backup/entry['path'],f)
  else:f.unlink(missing_ok=True)
 print('Apply failed; changes from this run were restored.',file=sys.stderr);raise
