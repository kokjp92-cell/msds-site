"""Use document locale already visible in the product card, without guessing document language."""
import argparse,re,json,shutil
from pathlib import Path
from html import escape
from html.parser import HTMLParser
from locale_fields import Card
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();checked=changed=0
for f in sorted((a.site/'products').glob('*.html')):
 src=f.read_text();c=Card();c.feed(src);fmt=next((v for v in c.props.values() if '언어' in v and '국가' in v),'');lang=re.search(r'언어\s+([^·]+)',fmt);region=re.search(r'국가\s+([^·]+)',fmt)
 if not lang or not region:continue
 language=lang[1].strip();country=region[1].strip();checked+=1;title=c.h1.strip()+' ['+language+' · '+country+'] | MSDS 모아';description=c.h1.strip()+'. 문서 언어 '+language+', 적용 국가 '+country+'. 제품명·공급자·개정일을 원문 및 납품 라벨과 대조하세요.'
 out=re.sub(r'<title>.*?</title>','<title>'+escape(title)+'</title>',src,count=1,flags=re.S|re.I)
 meta='<meta name="description" content="'+escape(description,quote=True)+'">';out=re.sub(r'<meta\b(?=[^>]*name=[\"\x27]description[\"\x27])[^>]*>',meta,out,count=1,flags=re.I)
 if out!=src:
  b=a.backup/f.relative_to(a.site);b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():shutil.copy2(f,b)
  f.write_text(out);changed+=1
print('DOCUMENT LOCALE SEO V90 COMPLETE',json.dumps(dict(explicit_locale_pages=checked,changed=changed)))
