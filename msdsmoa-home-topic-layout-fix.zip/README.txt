홈 상단의 단독 염화칼슘 링크만 제거하는 표시 수정본입니다.
모아보기 페이지·검색 데이터·제조사 자료실·상세주소·사이트맵은 유지합니다.
v60 데이터 배포 후 적용하는 소규모 수정 파일입니다. 자료 누적본을 대체하지 않습니다.
적용: sudo python3 apply-home-topic-layout.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-home-topic-layout-backup
