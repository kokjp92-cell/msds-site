import os
import re
import sys
import tempfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
sections = Path(__file__).with_name('detail-sections.html').read_text()
catalogs = ('ssangkom', 'hansol', 'lxmma', 'tspc')
paths = set()
for maker in catalogs:
    catalog = root / f'manufacturer-{maker}.html'
    paths.update(re.findall(r'<h3><a href="/?(products/[a-zA-Z0-9_-]+\.html)"', catalog.read_text()))

updates = {}
complete = 0
for relative in sorted(paths):
    path = root / relative
    if not path.is_file():
        raise SystemExit(f'Detail file missing: {relative}')
    page = path.read_text()
    if all(f'class="{name}"' in page for name in ('ppe-selection', 'msds-law', 'ppe-shopping')):
        complete += 1
        continue
    if '<dt>문서 형식</dt>' not in page:
        continue
    if page.count('</main>') != 1 or any(f'class="{name}"' in page for name in ('ppe-selection', 'msds-law', 'ppe-shopping')):
        raise SystemExit(f'Unexpected detail structure: {relative}')
    updates[path] = page.replace('</main>', sections + '\n</main>', 1)

if not updates and not complete:
    raise SystemExit('No matching product detail pages found.')
for path, page in updates.items():
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as out:
        out.write(page)
    temp = Path(out.name)
    try:
        temp.chmod(path.stat().st_mode & 0o777)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)
print(f'DETAIL SECTIONS COMPLETE: {len(updates)} updated; {complete} already complete')
