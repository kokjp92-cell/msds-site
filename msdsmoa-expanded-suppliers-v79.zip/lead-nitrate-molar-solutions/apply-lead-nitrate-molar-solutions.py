"""Add verified supplier catalog entries to MSDS Moa."""
import argparse
from collections import defaultdict
import hashlib
from html import escape
import xml.etree.ElementTree as ET
import json
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def asset(name, content, extension):
    digest = hashlib.sha256(content.encode()).hexdigest()[:12]
    return f"/assets/{name}-{digest}.{extension}"


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
root = args.site
package = Path(__file__).parent
home = root / "index.html"
directory = root / "manufacturers.html"
sitemap = root / "sitemap.xml"
html = home.read_text(encoding="utf-8")
search = re.search(r'id="msds-search-bundle" content="(/assets/home-search-[a-f0-9]+\.js)"', html)
detail = re.search(r'id="msds-detail-index" content="(/assets/detail-index-[a-f0-9]+\.js)"', html)
if not search or not detail:
    raise SystemExit("Expected the optimized home. No changes made.")
bundle = (root / search[1][1:]).read_text(encoding="utf-8")
if "// lead-nitrate-molar-solutions-documents-v1" in bundle:
    print("Suppliers already added.")
    raise SystemExit(0)
prefix = "window.msdsDetailIndex="
raw = (root / detail[1][1:]).read_text(encoding="utf-8").strip()
if not raw.startswith(prefix):
    raise SystemExit("Unexpected detail index. No changes made.")
index = json.loads(raw[len(prefix):].removesuffix(";"))
rows = json.loads((package / "lead-nitrate-molar-solutions-products.json").read_text(encoding="utf-8"))
companies = {'태진상사':'taejin'}

def compact(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def render(template, fields):
    return re.sub(r"\{\{([A-Z]+)\}\}", lambda m: fields[m[1]], template)


namespace = "http://www.sitemaps.org/schemas/sitemap/0.9"
ET.register_namespace("", namespace)
tree = ET.parse(sitemap)
known = {item.text for item in tree.findall(f".//{{{namespace}}}loc")}

def include_url(url):
    if url not in known:
        node = ET.SubElement(tree.getroot(), f"{{{namespace}}}url")
        ET.SubElement(node, f"{{{namespace}}}loc").text = url
        known.add(url)


detail_template = (package / "detail-template.html").read_text(encoding="utf-8")
catalog_template = (package / "catalog-template.html").read_text(encoding="utf-8")
outputs = {}
directory_cards = []
records = []
directory_updates = {}
site = "https://msdsmoa.com"
for company, slug in companies.items():
    entries = [row for row in rows if row["company"] == company]
    catalog = f"/manufacturer-{slug}.html"
    source = entries[0]["source"]
    cards = []
    for row in entries:
        name, url = row["name"], row["url"]
        key = compact([company, name, url])
        if key in index or compact([company, name]) in index:
            raise SystemExit(f"Existing detail link for {company} / {name}. No changes made.")
        detail_url = "/products/" + hashlib.sha256(key.encode()).hexdigest()[:24] + ".html"
        canonical = site + detail_url
        index[key] = detail_url
        include_url(canonical)
        fields = dict(TITLE=f"{company} {name} MSDS", DESCRIPTION=f"{company} {name} 공개 MSDS. 언어·개정일·보관본 여부를 확인하세요.",
                      CANONICAL=canonical, NAME=name, COMPANY=company, FORMAT=row["format"],
                      PDF=url, BUTTON=row["button"], SOURCE=row["source"], CATALOG=catalog)
        outputs[detail_url] = render(detail_template, {k: escape(v) for k, v in fields.items()})
        records.append(dict(company=company, name=name, url=url, verifiedList=row["source"],
                            keywords=f"{company} {name} " + row.get("keywords", ""),
                            detail=row["format"], label=row["button"],
                            instructions="공급사 원문에서 제품명과 개정일을 확인하세요."))
        cards.append(
            f'<article class="row catalog-item" data-search="{escape(company + " " + name)}">'
            f'<div><div class="status">{company} · {escape(row["format"])}</div><h3><a href="{detail_url}">{escape(name)}</a></h3></div>'
            f'<div class="result-actions"><a class="action" href="{escape(url)}" target="_blank" '
            f'rel="noopener noreferrer">{escape(row["button"])}</a></div></article>'
        )
    existing_catalog = root / catalog[1:]
    if existing_catalog.exists():
        previous = existing_catalog.read_text(encoding="utf-8")
        match = re.search(r'<section aria-labelledby="catalog-heading">(.*?)</section>', previous, re.S)
        if not match: raise SystemExit("Existing catalog structure needs review: " + catalog)
        old_count = re.search(r'등록 자료 ([\d,]+)건', previous)
        if not old_count: raise SystemExit("Existing catalog count missing: " + catalog)
        count = int(old_count[1].replace(",", "")); total_count = count + len(entries)
        previous = previous[:match.end(1)] + "".join(cards) + previous[match.end(1):]
        previous = previous.replace("등록 자료 " + old_count[1] + "건", f"등록 자료 {total_count:,}건")
        previous = previous.replace(f"1–{count}번째 자료", f"1–{total_count}번째 자료")
        outputs[catalog] = previous
        directory_updates[catalog] = total_count
    else:
        outputs[catalog] = render(catalog_template, dict(COMPANY=company, COUNT=str(len(entries)),
                                                    SLUG=catalog[1:-5], SOURCE=source, CARDS="".join(cards)))
    include_url(site + catalog)
    if not existing_catalog.exists(): directory_cards.append(
        f'<article class="row"><div><h2>{company} MSDS</h2><p class="meta">국내 업체의 공개 원문으로 연결합니다. 자료별 언어·연도와 보관본 여부를 확인하세요.</p>'
        f'<p class="catalog-count">등록 자료 {len(entries)}건</p></div><a class="action" href="{catalog}">자료 목록 보기 →</a></article>'
    )
if len(tree.getroot()) > 50000:
    raise SystemExit("Sitemap limit exceeded. No changes made.")

index_js = prefix + compact(index) + ";\n"
detail_path = asset("detail-index", index_js, "js")
outputs[detail_path] = index_js
groups = defaultdict(dict)
for key, destination in index.items():
    groups[json.loads(key)[0]][key] = destination
manifest = {}
for company, entries in sorted(groups.items()):
    content = compact(entries)
    path = asset("detail-company", content, "json")
    manifest[company] = path
    if not (root / path[1:]).is_file():
        outputs[path] = content

for name, value in [("manufacturerDetailSource", detail_path), ("manufacturerDetailFiles", manifest)]:
    old = re.search(rf"(?m)^const {name} = .+;$", bundle)
    if not old:
        raise SystemExit("Expected manufacturer-specific detail links. No changes made.")
    bundle = replace_once(bundle, old[0], f"const {name} = {compact(value)};")
anchor = "const results = document.querySelector('#results');"
bundle = replace_once(bundle, anchor, "// lead-nitrate-molar-solutions-documents-v1\nproducts.push(..." + compact(records) + ");\n" + anchor)
total = re.search(r'등록 자료 ([\d,]+)건', html)
if not total:
    raise SystemExit("Could not find the home document count.")
new_total = f"{int(total[1].replace(',', '')) + len(records):,}"
html = html.replace(total[1] + "건", new_total + "건")
bundle = bundle.replace(total[1] + "건", new_total + "건")
search_path = asset("home-search", bundle, "js")
outputs[search_path] = bundle
html = replace_once(html, search[1], search_path)
html = replace_once(html, detail[1], detail_path)
directory_html = directory.read_text(encoding="utf-8")
for catalog, count in directory_updates.items():
    pat = r'<article class="row">(?:(?!</article>).)*href="/?' + re.escape(catalog.lstrip('/')) + r'"(?:(?!</article>).)*</article>'
    match = re.search(pat, directory_html, re.S)
    if not match: raise SystemExit("Existing directory card missing: " + catalog)
    replacement = re.sub(r'등록 자료 [\d,]+건', f'등록 자료 {count:,}건', match[0])
    directory_html = replace_once(directory_html, match[0], replacement)
reference = re.search(r'<article class="row">(?:(?!</article>).)*href="/?manufacturer-zeller\.html"(?:(?!</article>).)*</article>', directory_html, re.S)
if not reference:
    raise SystemExit("Could not locate the manufacturer directory cards.")
directory_html = replace_once(directory_html, reference[0], reference[0] + "".join(directory_cards))

# Keep the directory summary aligned with the home and its company cards.
card_count = len(re.findall(r'<article class="row"><div><h2>', directory_html))
directory_html = re.sub(r'총 [\d,]+개 제조사·브랜드·공급사, 등록 자료 [\d,]+건입니다\.', f'총 {card_count:,}개 제조사·브랜드·공급사, 등록 자료 {new_total}건입니다.', directory_html)
args.backup.mkdir(parents=True, exist_ok=False)
for page in (home, directory, sitemap):
    shutil.copy2(page, args.backup / page.name)
for url, content in outputs.items():
    publish(root / url[1:], content, 0o644)
publish(sitemap, ET.tostring(tree.getroot(), encoding="unicode", xml_declaration=True), sitemap.stat().st_mode)
publish(directory, directory_html, directory.stat().st_mode)
publish(home, html, home.stat().st_mode)
print(f"NEW SUPPLIERS COMPLETE: {len(records)} documents, {len(companies)} suppliers\nBackup: {args.backup}")
