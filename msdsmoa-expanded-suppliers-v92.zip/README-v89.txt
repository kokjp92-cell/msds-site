MSDS 모아 누적 v89 / 2026-11-25
기존 v88와 이전 모든 추가분/SEO/내부검색 포함. 검색자료수45,154건 유지. 새업체/제품추가가 아니라 기존 검색자료4건의 누락 상세페이지 연결복구.
전체검색원본45154건(고유외부URL44811개)의 필드/상세주소매핑검사에서누락0. 외부44811URL응답전수검사는아님. 동명문서전체원문비교완료아님. 자세한미완료범위completion/reports/remaining-external-scope.txt.
수정1: 대한유화7건의javascript:; 버튼을공식자료실안내로변경. 잘못된추가언어버튼제거. SB9260유효영문PDF유지. 원본출처데이터와상세주소정체성보존.
수정2: 노루페인트 CUH000091/PXJ00238A/SEN000201/CIA013851의원문PDF제품명/해시확인후상세페이지/제조사자료실/전체검색인덱스/업체별인덱스/사이트맵복구. 홈등록수증가없음. 기존누락주소4개추가로사이트맵45466URL예상. 이전v88중복2주소제외유지.
수정3: 설치마지막SEO및전체검색원본검사자동실행. deploy-v89.sh는추가로서버의모든제품파일과내부링크검사. 기존자료실223개, 식별설명410건유지. 원문PDF재배포하지않음.
적용: sudo bash deploy-v89.sh /var/www/msdsmoa
또는 sudo python3 apply-expanded-suppliers.py /var/www/msdsmoa --backup /home/ubuntu/msdsmoa-v89-backup 후 python3 sitewide-quality/verify-sitewide-quality.py /var/www/msdsmoa
최종V89 LOCAL DEPLOY VERIFY OK 확인. 백업경로출력됨. 공개URL검색확인과Search Console색인보고서는서버반영후별도확인필요.
로컬검증:1113HTML/1011제품상세, 전체45154원본매핑, 7버튼DOM동작,4상세/검색/자료실/사이트맵,JS문법,전체설치재실행불변. 실서버파일전체검사는아직수행하지않음. SearchConsole연결/보고서가없어색인제외사유/제출/노출분석을수행하지않음.
서버배포는수행하지않았고사용자가직접배포.
