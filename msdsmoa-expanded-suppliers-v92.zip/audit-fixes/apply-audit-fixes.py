import argparse,json,re,hashlib,shutil
from pathlib import Path
from html import unescape,escape
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();pkg=Path(__file__).resolve().parent;issues=json.loads((pkg/'link-issues.json').read_text());aliases=json.loads((pkg/'canonical-aliases.json').read_text());changed=0

def write(f,out):
 global changed
 if f.read_text()==out:return
 b=a.backup/f.relative_to(a.site);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():shutil.copy2(f,b)
 f.write_text(out);changed+=1

def anchor(m):
 tag=m[0];v=re.search(r'\bhref=([\"\x27])(.*?)\1',tag,re.S)
 if not v:return tag
 u=unescape(v[2])
 if u not in issues:return tag
 start=tag[:tag.index('>')+1];start=start[:v.start(2)]+escape(issues[u],quote=True)+start[v.end(2):]
 return start+'원문 경로 오류 · 공급사에서 확인</a>'
for f in a.site.rglob('*.html'):
 s=f.read_text();s=s.replace('원문 파일 없음 · 공급사에서 MSDS 요청','원문 경로 오류 · 공급사에서 확인');out=re.sub(r'<a\b[^>]*>.*?</a>',anchor,s,flags=re.S|re.I)
 if '/products/' in '/'+f.relative_to(a.site).as_posix() and out!=s and 'link-issue-v88' not in out:
  note='<p class="source-caution" id="link-issue-v88">2026-11-25 점검에서 등록된 원문 다운로드 경로에 파일 없음 또는 HTTP 오류가 확인되었습니다. 이 등록 경로에서는 다운로드를 확인할 수 없습니다. 공급사에 해당 제품의 국문 MSDS를 요청하세요.</p>'
  out=out.replace('<section>',note+'<section>',1)
 write(f,out)
home=a.site/'index.html';h=home.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];f=a.site/old.lstrip('/');s=f.read_text()
if '// audit-link-v88' not in s:
 mark='function productRow(product) {';assert mark in s;s=s.replace(mark,'const linkIssuesV88 = '+json.dumps(issues,ensure_ascii=False)+';\n'+mark+'\n  const linkIssue = linkIssuesV88[product.url];')
 s=s.replace('const kind = formatCode(product);',"const kind = linkIssue ? 'lookup' : formatCode(product);")
 s=s.replace("details.append(badge);","details.append(badge);\n  if (linkIssue) details.append(element('p', '2026-11-25 확인: 등록 원문 경로에 HTTP 오류가 있어 공급사 확인이 필요합니다.', 'source-caution'));")
 s=s.replace("(product.label || '공식 목록 열기 ↗').replace(/^공식\\s+/, '')","linkIssue ? '공급사에서 MSDS 요청' : (product.label || '공식 목록 열기 ↗').replace(/^공식\\s+/, '')")
 s=s.replace('link.href = product.url;','link.href = linkIssue || product.url;');s+='\n// audit-link-v88\n';new='/assets/home-search-'+hashlib.sha256(s.encode()).hexdigest()[:12]+'.js';(a.site/new.lstrip('/')).write_text(s);write(home,h.replace(old,new))
# Refresh the exact issue map in an already patched search bundle.
home=a.site/'index.html';h=home.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];bundle=(a.site/old.lstrip('/')).read_text().replace('원문 파일이 없어 공급사에 MSDS 요청이 필요합니다.','등록 원문 경로에 HTTP 오류가 있어 공급사 확인이 필요합니다.')
updated=re.sub(r'^const linkIssuesV88 = .*;$','const linkIssuesV88 = '+json.dumps(issues,ensure_ascii=False)+';',bundle,flags=re.M)
if updated!=bundle:
 new='/assets/home-search-'+hashlib.sha256(updated.encode()).hexdigest()[:12]+'.js';(a.site/new.lstrip('/')).write_text(updated);write(home,h.replace(old,new))
f=a.site/'sitemap.xml';s=f.read_text()
for rel in aliases:s=re.sub(r'<url>\s*<loc>'+re.escape('https://msdsmoa.com/'+rel)+r'</loc>.*?</url>\s*','',s,flags=re.S)
write(f,s);print('AUDIT FIXES V88 COMPLETE',changed)
