#!/usr/bin/env python3
import argparse,json,re,sys
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
class Links(HTMLParser):
 def __init__(self,s):super().__init__(convert_charrefs=True);self.hrefs=[];self.feed(s)
 def handle_starttag(self,t,a):
  if t=='a':self.hrefs.append(dict(a).get('href',''))
p=argparse.ArgumentParser();p.add_argument('site',type=Path);a=p.parse_args();site=a.site.resolve();files=list((site/'products').glob('*.html'));errors=[];related=0
for f in files:
 s=f.read_text()
 if s.count('id="product-assistance-title"')!=1:errors.append(str(f.relative_to(site))+': assistance section missing or repeated');continue
 for u in Links(s).hrefs:
  if u.startswith('/products/'):
   related+=1;dest=(site/unquote(urlsplit(u).path).lstrip('/')).resolve()
   if not dest.is_relative_to(site) or not dest.is_file():errors.append(str(f.relative_to(site))+': missing related detail '+u)
for name in ['msds-document-check.html','msds-document-context-v55.js','sitewide-quality-v55.css','sitewide-quality-report-v55.json','document-actions-v56.js','site-version.json','document-integrity-report-v56.json']:
 if not (site/name).is_file():errors.append(name+': missing')
if (site/'site-version.json').exists() and json.loads((site/'site-version.json').read_text()).get('version')!='v90':errors.append('Version is not v90')
report=json.loads((site/'sitewide-quality-report-v55.json').read_text()) if (site/'sitewide-quality-report-v55.json').exists() else {}
if report.get('products_enriched')!=len(files):errors.append('Coverage count does not match current product files')
if report.get('missing_indexed_files',0):errors.append('Indexed product files missing: '+str(report['missing_indexed_files']))
for f in site.glob('*.html'):
 s=f.read_text()
 if '</main>' in s and 'sitewide-navigation-v55 start' not in s:errors.append(f.name+': shared navigation missing')
print(json.dumps({'product_files_checked':len(files),'internal_product_links_checked':related,'errors':len(errors)},ensure_ascii=False))
for e in errors[:30]:print(e)
if errors:sys.exit(1)
print('SITEWIDE QUALITY V90 VERIFY OK')
