"""Apply the Samjung, Poongsan and Shinil catalog updates in order."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
package = Path(__file__).resolve().parent
for supplier in ("samjung", "poongsan", "shinil"):
    script = package / supplier / f"apply-{supplier}.py"
    subprocess.run(
        [sys.executable, str(script), str(args.site), "--backup", str(args.backup / supplier)],
        check=True,
    )
