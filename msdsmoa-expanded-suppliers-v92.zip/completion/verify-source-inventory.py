"""Validate all locally deployed search source records and detail mappings, no external requests."""
import argparse,json,re
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);a=ap.parse_args();root=a.site;h=(root/'index.html').read_text();path=lambda id:re.search('id="'+id+'" content="([^"]+)"',h)[1];bundle=(root/path('msds-search-bundle')[1:]).read_text();index=json.loads((root/path('msds-detail-index')[1:]).read_text().removeprefix('window.msdsDetailIndex=').strip().removesuffix(';'));rows=[dict(company=r[0],name=r[1],url=r[2]) for r in json.loads(re.search(r'^const catalog = (.*);$',bundle,re.M)[1])]
for m in re.finditer(r'products\.push\(\.\.\.(\[.*\])\);',bundle):rows.extend(json.loads(m[1]))
errors=[]
for file,company in [('noroo-products.json','노루페인트'),('kcc-products.json','KCC'),('3m-products.json','한국쓰리엠'),('samhwa-products.json','삼화페인트')]:
 p=root/file
 if not p.exists():errors.append('Missing source dataset: '+file);continue
 for r in json.loads(p.read_text()):rows.append(dict(r,company=company))
compact=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'));invalid=0
for r in rows:
 c,n,u=r.get('company'),r.get('name'),r.get('url','')
 if not c or not n:errors.append('Missing product identity');continue
 if not re.match(r'^https?://',u,re.I):
  invalid+=1
  if c!='대한유화' or u!='javascript:;' or '// completion-v89' not in bundle:errors.append('Unsupported source link: '+str(c)+' / '+n)
 if compact([c,n,u]) not in index and compact([c,n]) not in index:errors.append('Missing detail mapping: '+c+' / '+n)
print(json.dumps(dict(source_rows_checked=len(rows),unique_source_urls=len({r.get('url') for r in rows}),guarded_invalid_source_rows=invalid,missing_or_invalid_count=len(errors),errors=errors[:30],network_requests=0),ensure_ascii=False));raise SystemExit(bool(errors))
