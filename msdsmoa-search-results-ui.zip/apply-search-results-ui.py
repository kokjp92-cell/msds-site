"""Improve home search results readability."""
import argparse
import hashlib
from pathlib import Path
import re
import shutil
import tempfile


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise SystemExit(f"Unexpected structure at {old[:90]!r}. No changes made.")
    return text.replace(old, new, 1)


def publish(path, content, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
        temporary = Path(handle.name)
    try:
        temporary.write_text(content, encoding="utf-8")
        temporary.chmod(mode & 0o777)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("site", type=Path)
parser.add_argument("--backup", type=Path, required=True)
args = parser.parse_args()
home = args.site / "index.html"
html = home.read_text(encoding="utf-8")
if 'id="msds-results-style"' in html:
    print("Search results UI patch already applied.")
    raise SystemExit(0)
search = re.search(r'<meta id="msds-search-bundle" content="(/assets/home-search-[a-f0-9]+\.js)">', html)
if not search or 'id="msds-search-results"' not in html:
    raise SystemExit("Expected the search-only home. No changes made.")

bundle = (args.site / search[1][1:]).read_text(encoding="utf-8")
outer = re.search(r'function measureMakerList\(\) \{.*?\nfunction render\(\) \{\n  listMeasurements.clear\(\);', bundle, re.S)
inner = re.search(r'    list.tabIndex = 0;\n    list.ariaLabel = company .*?\n    listMeasurements.add\(measureList\);', bundle, re.S)
if not outer or not inner:
    raise SystemExit("Expected the existing result measurements. No changes made.")
bundle = replace_once(bundle, outer[0], "let previousResultsQuery;\nfunction render() {")
bundle = replace_once(bundle, inner[0], "")
bundle = replace_once(bundle, "      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(measureList);\n", "")
bundle = replace_once(bundle, " if (group.open) measureList();", "")
bundle = replace_once(bundle, "group.append(summary, list, hint);", "group.append(summary, list);")
bundle = replace_once(bundle, "  if (typeof requestAnimationFrame === 'function') requestAnimationFrame(measureMakerList);\n", "")
bundle = replace_once(bundle, "  panel.hidden = !normalizedQuery;", """  const sameQuery = normalizedQuery === previousResultsQuery;
  previousResultsQuery = normalizedQuery;
  panel.hidden = !normalizedQuery;""")
old = "  const expanded = new Set(Array.from(results.querySelectorAll('details[open]'), group => group.dataset.company));"
new = """  const groupStates = new Map(sameQuery
    ? Array.from(results.querySelectorAll('details[data-company]'), group => [group.dataset.company, group.open])
    : []);"""
bundle = replace_once(bundle, old, new)
bundle = replace_once(bundle, "group.open = expanded.has(company);",
                      "group.open = groupStates.get(company) ?? (matches.length <= 10);")
bundle = replace_once(bundle, re.search(r": '전체 [\d,]+건 검색 준비 완료 · 언어·국가·등급별 문서는 별도 항목입니다\.';", bundle)[0], ": '';")
asset = "/assets/home-search-" + hashlib.sha256(bundle.encode()).hexdigest()[:12] + ".js"
html = replace_once(html, search[0], search[0].replace(search[1], asset))
styles = """<style id="msds-results-style">
#msds-search-results #results{max-height:none;overflow:visible;scrollbar-gutter:auto;padding:0;border:0;background:transparent}
#msds-search-results #results .maker-products{max-height:none;overflow:visible;scrollbar-gutter:auto}
#msds-search-results #results .maker{margin:0 0 12px}
#msds-search-results #results .maker>summary{padding:14px 16px}
#msds-search-results #results .maker-products .row h3{font-size:1.125rem;line-height:1.45;overflow-wrap:anywhere}
#msds-search-results #results .maker-products .row .product-detail-link{display:inline-block;margin:4px 0}
@media(max-width:640px){
  #msds-search-results #results .maker-products .row .result-actions{align-items:stretch}
}
</style>"""
html = replace_once(html, "</head>", styles + "</head>")
args.backup.mkdir(parents=True, exist_ok=False)
shutil.copy2(home, args.backup / home.name)
publish(args.site / asset[1:], bundle, 0o644)
publish(home, html, home.stat().st_mode)
print(f"SEARCH RESULTS UI COMPLETE\nBackup: {args.backup / home.name}")
