"""Repair only explicitly verified product/detail associations; preserve unrelated documents."""
import argparse,json,re,shutil,hashlib,sys
from pathlib import Path
from html import escape,unescape
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'locale-seo'))
from locale_fields import Card
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);ap.add_argument('--mode',choices=['all','details','search'],default='all');a=ap.parse_args();pkg=Path(__file__).parent;changed=0

def write(f,out):
 global changed
 src=f.read_text()
 if out==src:return
 b=a.backup/f.relative_to(a.site);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():shutil.copy2(f,b)
 f.write_text(out);changed+=1
if a.mode!='search':
 for r in json.loads((pkg/'detail-source-repairs.json').read_text()):
  f=a.site/r['path'].lstrip('/');src=f.read_text();c=Card();c.feed(src)
  if c.props.get('제품명')!=r['name']:raise SystemExit('Product identity changed; review required: '+r['path'])
  fmt=c.props.get('자료 정보',c.props.get('문서 형식',''))
  if r['product_code'] and r['product_code'] not in fmt:raise SystemExit('Product code changed: '+r['path'])
  old,new=r['previous_detail_url'],r['registered_url'];links=[unescape(x[1]) for x in re.findall(r'href=([\"\x27])(.*?)\1',src,re.S)]
  if new in links and old not in links:continue
  if old not in links:raise SystemExit('Expected original detail link missing: '+r['path'])
  def href(m):return m[1]+escape(new,quote=True)+m[3] if unescape(m[2])==old else m[0]
  out=re.sub(r'(\bhref=[\"\x27])(.*?)([\"\x27])',href,src,flags=re.S)
  # A summary attached to the wrong source must not survive a source correction.
  out=re.sub(r'<section\b[^>]*\bid=[\"\x27]reviewed-product-v53[\"\x27][^>]*>.*?</section>','',out,flags=re.S)
  out=re.sub(r'<!-- verified-identity-v91 start -->.*?<!-- verified-identity-v91 end -->','',out,flags=re.S)
  write(f,out)
if a.mode!='details':
 home=a.site/'index.html';h=home.read_text();old=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];js=(a.site/old[1:]).read_text();rows=json.loads((pkg/'source-resolutions.json').read_text());compact=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'));mapping={compact([r['company'],r['name'],r['registered_url']]):r['resolved_url'] for r in rows};declaration='const sourceResolutionsV92 = '+json.dumps(mapping,ensure_ascii=False)+';'
 if '// scoped-source-resolutions-v92' not in js:
  marker='function productRow(product) {'
  if js.count(marker)!=1:raise SystemExit('Unexpected search renderer')
  js=js.replace(marker,declaration+'\n'+marker+'\n  const resolvedSourceV92 = sourceResolutionsV92[JSON.stringify([product.company, product.name, product.url])] || product.url;',1)
  target='link.href = linkIssue || product.url;'
  if target not in js:raise SystemExit('Expected guarded primary link missing')
  js=js.replace(target,'link.href = linkIssue || resolvedSourceV92;');js+='\n// scoped-source-resolutions-v92\n'
 else:js=re.sub(r'^const sourceResolutionsV92 = .*;$',declaration,js,flags=re.M)
 new='/assets/home-search-'+hashlib.sha256(js.encode()).hexdigest()[:12]+'.js';(a.site/new[1:]).write_text(js);write(home,h.replace(old,new))
print('SCOPED SOURCE REPAIRS V92 COMPLETE',changed,'verified detail associations',15)
