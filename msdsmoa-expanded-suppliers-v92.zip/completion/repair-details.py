import argparse,json,re,hashlib,shutil
from pathlib import Path
from html import escape
ap=argparse.ArgumentParser();ap.add_argument('site',type=Path);ap.add_argument('--backup',type=Path,required=True);a=ap.parse_args();pkg=Path(__file__).resolve().parent;rows=json.loads((pkg/'missing-details.json').read_text());root=a.site;home=root/'index.html';h=home.read_text();ixpath=re.search(r'id="msds-detail-index" content="([^"]+)"',h)[1];prefix='window.msdsDetailIndex=';index=json.loads((root/ixpath[1:]).read_text().removeprefix(prefix).strip().removesuffix(';'));compact=lambda o:json.dumps(o,ensure_ascii=False,separators=(',',':'));template=(pkg.parent/'taejin/detail-template.html').read_text();catalog=root/'manufacturer-noroo.html';assert catalog.exists(),'Existing Noroo catalog required';cards=[];newkeys={};created=0

def write(f,s):
 if f.exists() and f.read_text()==s:return
 if f.exists():
  b=a.backup/f.relative_to(root);b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():shutil.copy2(f,b)
 f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
for row in rows:
 key=compact([row['company'],row['name'],row['url']]);short=compact([row['company'],row['name']]);path=index.get(key) or index.get(short)
 if path:continue
 path='/products/'+hashlib.sha256(key.encode()).hexdigest()[:24]+'.html';fields=dict(TITLE='노루페인트 '+row['name']+' MSDS',DESCRIPTION='노루페인트 '+row['name']+' 제품코드 '+row['code']+'의 공식 MSDS 원문 경로를 확인하세요.',CANONICAL='https://msdsmoa.com'+path,NAME=row['name'],COMPANY='노루페인트',FORMAT='공식 제품 목록 · 제품코드 '+row['code']+' · 원문 개정일은 문서에서 확인',PDF=row['url'],BUTTON='공식 MSDS 원문 확인',SOURCE=row['url'],CATALOG='/manufacturer-noroo.html')
 out=template
 for k,v in fields.items():out=out.replace('{{'+k+'}}',escape(v,quote=True))
 assert '{{' not in out;write(root/path[1:],out);index[key]=path;newkeys[key]=path;created+=1;cards.append('<article class="row"><h3><a href="'+path+'">'+escape(row['name'])+'</a></h3><p>노루페인트 · 제품코드 '+escape(row['code'])+'</p><a href="'+escape(row['url'],quote=True)+'" target="_blank" rel="noopener noreferrer">공식 MSDS 원문 확인</a></article>')
if created:
 raw=prefix+compact(index)+';';newix='/assets/detail-index-'+hashlib.sha256(raw.encode()).hexdigest()[:12]+'.js';write(root/newix[1:],raw);h=h.replace(ixpath,newix)
 bundlepath=re.search(r'id="msds-search-bundle" content="([^"]+)"',h)[1];bundle=(root/bundlepath[1:]).read_text();manifest=json.loads(re.search(r'^const manufacturerDetailFiles = (.*);$',bundle,re.M)[1]);old=manifest['노루페인트'];shard=json.loads((root/old[1:]).read_text());shard.update(newkeys);raw=compact(shard);new='/assets/detail-company-'+hashlib.sha256(raw.encode()).hexdigest()[:12]+'.json';write(root/new[1:],raw);bundle=bundle.replace(old,new);newbundle='/assets/home-search-'+hashlib.sha256(bundle.encode()).hexdigest()[:12]+'.js';write(root/newbundle[1:],bundle);h=h.replace(bundlepath,newbundle);write(home,h)
 block='<section id="noroo-more-v89"><h2>노루페인트 자료 더 보기</h2>'+''.join(cards)+'</section>';write(catalog,catalog.read_text().replace('</main>',block+'</main>',1))
 sitemap=root/'sitemap.xml';s=sitemap.read_text();extra=''.join('<url><loc>https://msdsmoa.com'+u+'</loc></url>' for u in newkeys.values() if 'https://msdsmoa.com'+u not in s);write(sitemap,s.replace('</urlset>',extra+'</urlset>'))
print('DETAIL REPAIRS V89 COMPLETE',created)
